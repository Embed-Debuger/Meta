import os
import csv
# os.environ['GLOG_minloglevel'] = '2'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
import tensorflow as tf
import torch
import torch.nn.functional as F
import MNN
from tensorflow.python.framework import graph_util
import time
F_mnn = MNN.expr
tf.compat.v1.disable_eager_execution()



def func():
    inputpath = "/home/finley/OperatorTest/question3/inputforConv/"
    weightpath="/home/finley/OperatorTest/question3/weightforConv/"
    for j in range(20):
        path1 = '/home/finley/OperatorTest/question3/conv_tf_gpu_output/'
        path2 = '/home/finley/OperatorTest/question3/conv_torch_gpu_output/'
        x = np.random.randn(1, 3, 12, 12)
        # np.save('input.npy', x) #导出此时的x
        np.save(inputpath + 'input' + str(j) + '.npy',x)

        weights = torch.empty(2, 2, 3, 8)
        torch.nn.init.constant_(weights, 5e-2)
        # np.save('weights.npy',weights)  #导出初始权重
        np.save(weightpath+'weight' + str(j) + '.npy',weights)

        out = open(file="/home/finley/OperatorTest/question3/conv_gpu.csv", mode="a", newline='')
        csv_writer = csv.writer(out)
        csv_writer.writerow(["No.","tf_time","torch_time"])

        weights_tf = tf.convert_to_tensor(weights.numpy(), dtype=tf.float32)
        weights_torch = torch.Tensor(weights.permute((3, 2, 0, 1)))

        stride = 2
        if x.shape[2] % stride == 0:
            pad = max(weights.shape[0] - stride, 0)
        else:
            pad = max(weights.shape[0] - (x.shape[2] % stride), 0)

        if pad % 2 == 0:
            pad_val = pad // 2
            padding = (pad_val, pad_val, pad_val, pad_val)
        else:
            pad_val_start = pad // 2
            pad_val_end = pad - pad_val_start
            padding = (pad_val_start, pad_val_end, pad_val_start, pad_val_end)

        x_tf = tf.convert_to_tensor(x.transpose((0, 2, 3, 1)), dtype=tf.float32)
        x_torch = torch.Tensor(x)
        x_torch = F.pad(x_torch, padding, "constant", 0)

        for i in range(1000):
            print(i)
            d=[]

            tf_t1 = time.time()
            sess = tf.compat.v1.Session()
            tf_conv2d = tf.nn.conv2d(x_tf,
                                     weights_tf,
                                     strides=[1, stride, stride, 1],
                                     padding="SAME")
            sess.run(tf.compat.v1.global_variables_initializer())
            tf_result = sess.run(tf_conv2d)
            tf_t2 = time.time()
            tf_time = tf_t2 - tf_t1

            # PyTorch Conv2D
            torch_t1 = time.time()
            torch_conv2d = F.conv2d(x_torch, weights_torch, padding=0, stride=stride)
            torch_t2 = time.time()
            torch_time = torch_t2 - torch_t1

            d.append(i)
            d.append(tf_time)
            d.append(torch_time)
            csv_writer.writerow(d)

            np.save(path1+'output'+str(j)+'_'+ str(i)+'.npy',tf_result)
            np.save(path2+'output'+str(j)+'_'+ str(i)+'.npy',torch_conv2d)



        out.close()




if __name__=='__main__':
    func()
