import os

os.environ['GLOG_minloglevel'] = '2'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
import tensorflow as tf
import torch
import torch.nn.functional as F
import MNN
import time
import csv
F_mnn = MNN.expr
tf.compat.v1.disable_eager_execution()

np.random.seed(0)
out = open(file="/home/finley/OperatorTest/conv_gpu/conv_diff_data2.csv", mode="a", newline='')
csv_writer = csv.writer(out)
csv_writer.writerow(["No.", "tf_torch_diff", "tf_torch_rediff", "tf_time", "torch_time"])


# path = "/home/finley/OperatorTest/conv_gpu/conv_input/"
i=-1
# for i in range(5000):
while 1:
    # print(i)
    i+=1
    print(i)
    # x_out = open(file=path + "input_" + str(i) + ".csv", mode="a", newline='')
    # csv_writer1 = csv.writer(x_out)
    # csv_writer1.writerow(["No.", "input"])
    d = []
    # xlist = []
    # xlist.append(i)
    # Create random weights and input
    weights = torch.empty(2, 2, 3, 8)
    torch.nn.init.constant_(weights, 5e-2)
    x = np.random.randn(1, 3, 12, 12)
    # xlist.append(x)

    weights_tf = tf.convert_to_tensor(weights.numpy(), dtype=tf.float32)
    weights_torch = torch.Tensor(weights.permute((3, 2, 0, 1)))

    # weights_mnn=F_mnn.const(weights_torch.flatten().tolist(), [8,3,3,3], F_mnn.data_format.NCHW)

    # Tensorflow padding behavior. Assuming that kH == kW to keep this simple.
    stride = 2
    if x.shape[2] % stride == 0:
        pad = max(weights.shape[0] - stride, 0)
    else:
        pad = max(weights.shape[0] - (x.shape[2] % stride), 0)

    if pad % 2 == 0:
        pad_val = pad // 2
        padding = (pad_val, pad_val, pad_val, pad_val)
    else:
        pad_val_start = pad // 2
        pad_val_end = pad - pad_val_start
        padding = (pad_val_start, pad_val_end, pad_val_start, pad_val_end)

    x_tf = tf.convert_to_tensor(x.transpose((0, 2, 3, 1)), dtype=tf.float32)
    x_torch = torch.Tensor(x)
    x_torch = F.pad(x_torch, padding, "constant", 0)
    # x_mnn = x.astype(np.float32)
    # x_mnn = F_mnn.const(x_mnn.flatten().tolist(), [1, 3, 10, 10], F_mnn.data_format.NCHW)

    # TF Conv2D
    # global graph
    # graph = tf.compat.v1.get_default_graph()
    tf_t1 = time.time()
    # with graph.as_default():
    sess = tf.compat.v1.Session()
    tf_conv2d = tf.nn.conv2d(x_tf,
                             weights_tf,
                             strides=[1, stride, stride, 1],
                             padding="SAME")
    sess.run(tf.compat.v1.global_variables_initializer())
    tf_result = sess.run(tf_conv2d)
    tf_t2=time.time()
    sess.close()
    tf_time=tf_t2-tf_t1

    # PyTorch Conv2D
    torch_t1=time.time()
    torch_conv2d = F.conv2d(x_torch, weights_torch, padding=0, stride=stride)
    torch_t2=time.time()
    torch_time=torch_t2-torch_t1
    torch.cuda.empty_cache()

    diff = np.mean(np.abs(tf_result.transpose((0, 3, 1, 2)) - torch_conv2d.detach().numpy()))
    re_diff = np.abs(
        np.mean(np.abs(tf_result.transpose((0, 3, 1, 2)) - torch_conv2d.detach().numpy()) / torch_conv2d.detach().numpy()))


    # MNN Conv2D
    # bias=[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
    # bias=np.zeros((8,))
    # bias_mnn=F_mnn.const(bias, [8,],F_mnn.data_format.NCHW)
    # mnn_conv2d=F_mnn.conv2d(x_mnn,weights_mnn,bias=bias_mnn,stride=[stride,stride],padding=[0,0])
    # print(mnn_conv2d.read())



    # out = open(file="output.csv", mode="a");
    # if diff >= 3.2 * (10 ** -8):  # 华为精度误差允许范围10^-6
    #     crashes = crashes + 1
    #     out.writelines(
    #         "%d crashes exist in %d cases, and the mean of abs Diff is %s.\n" % (crashes, i + 1, format(diff)))
    #     print("%d crashes exist in %d cases, and the mean of abs Diff is %s." % (crashes, i + 1, format(diff)))
    # out.close()
    d.append(i)
    d.append(diff)
    d.append(re_diff)
    d.append(tf_time)
    d.append(torch_time)
    csv_writer.writerow(d)
    # csv_writer1.writerow(xlist)
    # x_out.close()
    #
out.close()