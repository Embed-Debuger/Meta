import os
import csv
# os.environ['GLOG_minloglevel'] = '2'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
import tensorflow as tf
import torch
import torch.nn.functional as F
import MNN
import time
F_mnn = MNN.expr

def func():
    inputpath = "/home/finley/OperatorTest/question3/inputfor4/"
    for j in range(20):
        print("No."+str(j)+"input")
        x=np.load(inputpath+'input'+str(j)+'.npy')

        path1 = '/home/finley/OperatorTest/question3/tanh_tf_cpu_output/'
        path2 = '/home/finley/OperatorTest/question3/tanh_torch_cpu_output/'

        path3 = '/home/finley/OperatorTest/question3/relu_tf_cpu_output/'
        path4 = '/home/finley/OperatorTest/question3/relu_torch_cpu_output/'

        path5 = '/home/finley/OperatorTest/question3/sigmoid_tf_cpu_output/'
        path6 = '/home/finley/OperatorTest/question3/sigmoid_torch_cpu_output/'

        path7 = '/home/finley/OperatorTest/question3/softmax_tf_cpu_output/'
        path8 = '/home/finley/OperatorTest/question3/softmax_torch_cpu_output/'

        out = open(file="/home/finley/OperatorTest/question3/tanh_cpu.csv", mode="a", newline='')
        csv_writer = csv.writer(out)
        csv_writer.writerow(["No.", "tf_cpu","torch_cpu","tf_time","torch_time"])

        out1 = open(file="/home/finley/OperatorTest/question3/relu_cpu.csv", mode="a", newline='')
        csv_writer1 = csv.writer(out1)
        csv_writer1.writerow(["No.", "tf_cpu", "torch_cpu", "tf_time", "torch_time"])

        out2 = open(file="/home/finley/OperatorTest/question3/sigmoid_cpu.csv", mode="a", newline='')
        csv_writer2 = csv.writer(out2)
        csv_writer2.writerow(["No.", "tf_cpu", "torch_cpu", "tf_time", "torch_time"])

        out3 = open(file="/home/finley/OperatorTest/question3/softmax_cpu.csv", mode="a", newline='')
        csv_writer3 = csv.writer(out3)
        csv_writer3.writerow(["No.", "tf_cpu", "torch_cpu", "tf_time", "torch_time"])

        for i in range(1000):
            print(i)
            d=[]
            d1=[]
            d2=[]
            d3=[]
            x_tf = tf.convert_to_tensor(x, dtype=tf.float32)
            x_torch = torch.Tensor(x)

            #tf tanh
            tf_t1=time.time()
            sess = tf.Session()
            tf_norm = tf.nn.tanh(x_tf)
            tf_result = sess.run(tf_norm)
            tf_t2=time.time()
            tf_time=tf_t2-tf_t1
            np.save(path1 + 'output' +str(j)+'_'+ str(i) + '.npy', tf_result)

            #pytorch tanh
            torch_t1=time.time()
            torch_norm = torch.nn.Tanh()
            torch_res = torch_norm(x_torch)
            torch_t2=time.time()
            torch_time=torch_t2-torch_t1
            np.save(path2 + 'output' + str(j)+'_'+str(i) + '.npy', torch_res)

            d.append(i)
            d.append(tf_result)
            d.append(torch_res)
            d.append(tf_time)
            d.append(torch_time)
            csv_writer.writerow(d)

            # tf relu
            tf_t1 = time.time()
            sess1 = tf.Session()
            tf_relu = tf.nn.relu(x_tf)
            tf_result = sess.run(tf_relu)
            tf_t2 = time.time()
            tf_time = tf_t2 - tf_t1
            np.save(path3 + 'output' +str(j)+'_'+ str(i) + '.npy', tf_result)

            # pytorch relu
            torch_t1 = time.time()
            torch_relu = torch.nn.ReLU()
            torch_res = torch_relu(x_torch)
            torch_t2 = time.time()
            torch_time = torch_t2 - torch_t1
            np.save(path4 + 'output' + str(j)+'_'+str(i) + '.npy', torch_res)

            d1.append(i)
            d1.append(tf_result)
            d1.append(torch_res)
            d1.append(tf_time)
            d1.append(torch_time)
            csv_writer1.writerow(d1)

            # tf sigmoid
            tf_t1 = time.time()
            sess = tf.Session()
            tf_sigmoid = tf.nn.sigmoid(x_tf)
            tf_result = sess.run(tf_sigmoid)
            tf_t2 = time.time()
            tf_time = tf_t2 - tf_t1
            np.save(path5 + 'output' + str(j)+'_'+str(i) + '.npy', tf_result)

            # pytorch sigmoid
            torch_t1 = time.time()
            torch_sigmoid = torch.nn.Sigmoid()
            torch_res = torch_sigmoid(x_torch)
            torch_t2 = time.time()
            torch_time = torch_t2 - torch_t1
            np.save(path6 + 'output' + str(j)+'_'+str(i) + '.npy', torch_res)

            d2.append(i)
            d2.append(tf_result)
            d2.append(torch_res)
            d2.append(tf_time)
            d2.append(torch_time)
            csv_writer2.writerow(d2)

            # tf softmax
            tf_t1 = time.time()
            sess = tf.Session()
            tf_softmax = tf.nn.softmax(x_tf)
            tf_result = sess.run(tf_softmax)
            tf_t2 = time.time()
            tf_time = tf_t2 - tf_t1
            np.save(path7 + 'output' + str(j)+'_'+str(i) + '.npy', tf_result)

            # pytorch sofxmax
            torch_t1 = time.time()
            torch_softmax = torch.nn.Softmax(dim=-1)
            torch_res = torch_softmax(x_torch)
            torch_t2 = time.time()
            torch_time = torch_t2 - torch_t1
            np.save(path8 + 'output' + str(j)+'_'+str(i) + '.npy', tf_result)

            d3.append(i)
            d3.append(tf_result)
            d3.append(torch_res)
            d3.append(tf_time)
            d3.append(torch_time)
            csv_writer3.writerow(d3)




        out.close()
        out1.close()
        out2.close()
        out3.close()


def forMNN():
    for j in range(20):
        x = np.random.randn(2, 2)
        path0='/home/finley/OperatorTest/question3/MNN_input_for4op/'
        path1 = '/home/finley/OperatorTest/question3/tanh_mnn_cpu_output/'
        path2 = '/home/finley/OperatorTest/question3/relu_mnn_cpu_output/'
        path3 = '/home/finley/OperatorTest/question3/sigmoid_mnn_cpu_output/'
        path4 = '/home/finley/OperatorTest/question3/softmax_mnn_cpu_output/'

        out = open(file="/home/finley/OperatorTest/question3/tanh_mnn.csv", mode="a", newline='')
        csv_writer = csv.writer(out)
        csv_writer.writerow(["No.", "mnn_cpu", "mnn_time"])

        out1 = open(file="/home/finley/OperatorTest/question3/relu_mnn.csv", mode="a", newline='')
        csv_writer1 = csv.writer(out1)
        csv_writer1.writerow(["No.", "mnn_cpu", "mnn_time"])

        out2 = open(file="/home/finley/OperatorTest/question3/sigmoid_mnn.csv", mode="a", newline='')
        csv_writer2 = csv.writer(out2)
        csv_writer2.writerow(["No.", "mnn_cpu", "mnn_time"])

        out3 = open(file="/home/finley/OperatorTest/question3/softmax_mnn.csv", mode="a", newline='')
        csv_writer3 = csv.writer(out3)
        csv_writer3.writerow(["No.", "mnn_cpu", "mnn_time"])

        np.save(path0+'input'+str(j)+'.npy',x)

        for i in range(1000):
            d = []
            d1 = []
            d2 = []
            d3 = []
            x_mnn = x.astype(np.float32)
            x_mnn = F_mnn.const(x_mnn.flatten().tolist(), [2, 2], F_mnn.data_format.NCHW)

            #MNN tanh
            mnn_t1 = time.time()
            mnn_res = F_mnn.tanh(x_mnn).read()
            mnn_t2 = time.time()
            mnn_time = mnn_t2 - mnn_t1

            mnn_res = np.asarray(mnn_res)
            mnn_res = mnn_res.astype(np.float32)
            mnn_res = mnn_res.reshape((2, 2))
            np.save(path1 + 'output' + str(j) + '_' + str(i) + '.npy', mnn_res)
            d.append(i)
            d.append(mnn_res)
            d.append(mnn_time)
            csv_writer.writerow(d)

            #MNN relu
            mnn_t1 = time.time()
            mnn_res = F_mnn.relu(x_mnn).read()
            mnn_t2 = time.time()
            mnn_time = mnn_t2 - mnn_t1

            mnn_res = np.asarray(mnn_res)
            mnn_res = mnn_res.astype(np.float32)
            mnn_res = mnn_res.reshape((2, 2))
            np.save(path2 + 'output' + str(j) + '_' + str(i) + '.npy', mnn_res)
            d1.append(i)
            d1.append(mnn_res)
            d1.append(mnn_time)
            csv_writer1.writerow(d1)

            # MNN sigmoid
            mnn_t1 = time.time()
            mnn_res = F_mnn.sigmoid(x_mnn).read()
            mnn_t2 = time.time()
            mnn_time = mnn_t2 - mnn_t1

            mnn_res = np.asarray(mnn_res)
            mnn_res = mnn_res.astype(np.float32)
            mnn_res = mnn_res.reshape((2, 2))
            np.save(path3 + 'output' + str(j) + '_' + str(i) + '.npy', mnn_res)
            d2.append(i)
            d2.append(mnn_res)
            d2.append(mnn_time)
            csv_writer2.writerow(d2)

            #MNN softmax
            mnn_t1 = time.time()
            mnn_res = F_mnn.softmax(x_mnn).read()
            mnn_t2 = time.time()
            mnn_time = mnn_t2 - mnn_t1

            mnn_res = np.asarray(mnn_res)
            mnn_res = mnn_res.astype(np.float32)
            mnn_res = mnn_res.reshape((2, 2))
            np.save(path4 + 'output' + str(j) + '_' + str(i) + '.npy', mnn_res)
            d3.append(i)
            d3.append(mnn_res)
            d3.append(mnn_time)
            csv_writer3.writerow(d3)

        out.close()
        out1.close()
        out2.close()
        out3.close()






if __name__=='__main__':
    # func()
    func()


