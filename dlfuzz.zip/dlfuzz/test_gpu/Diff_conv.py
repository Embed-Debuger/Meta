import numpy as np
import csv
import torch
import tensorflow as tf


def conv(p1,p2):
    path='/home/finley/OperatorTest/question3/diff_conv_tf.csv'
    out = open(file=path, mode="a", newline='')
    csv_writer = csv.writer(out)
    csv_writer.writerow(["No.", "diff_cpu","diff_gpu"])
    for j in range(20):
        d=[]
        sum1=np.zeros((1,6,6,8))
        sum2=np.zeros((1,6,6,8))
        list_cpu=[]
        list_gpu=[]


        for i in range(1000):
            cpu_out=np.load(p1+'output'+str(j)+'_'+str(i)+'.npy')
            gpu_out=np.load(p2+'output'+str(j)+'_'+str(i)+'.npy')
            #求均方差
            sum1+=cpu_out
            sum2+=gpu_out
            list_cpu.append(cpu_out)
            list_gpu.append(gpu_out)


        avg1=sum1/1000
        avg2=sum2/1000
        diff=np.mean(np.abs(avg1-avg2))
        print("diff between tf's cpu and gpu:",diff)
        sd_cpu=np.zeros((1,6,6,8))
        sd_gpu=np.zeros((1,6,6,8))

        for i in range(1000):
            cpu_out = list_cpu[i]
            gpu_out = list_gpu[i]
            sd_cpu+=np.square(cpu_out-avg1)
            sd_gpu+=np.square(gpu_out-avg2)

        sd_cpu=np.sqrt(sd_cpu/1000)
        sd_gpu=np.sqrt(sd_gpu/1000)
        print("第"+str(j)+"个输入的"+"标准差-cpu为：",sd_cpu)
        print("第"+str(j)+"个输入的"+"标准差-gpu为：",sd_gpu)

        d.append(j)
        d.append(sd_cpu)
        d.append(sd_gpu)
        csv_writer.writerow(d)

    out.close()

def conv_torch(p1,p2):
    path = '/home/finley/OperatorTest/question3/diff_conv_torch.csv'
    out = open(file=path, mode="a", newline='')
    csv_writer = csv.writer(out)
    csv_writer.writerow(["No.", "diff_cpu", "diff_gpu"])
    for j in range(20):
        sum1=np.zeros((1,8,6,6))
        sum2=np.zeros((1,8,6,6))
        list_cpu=[]
        list_gpu=[]
        d=[]


        for i in range(1000):
            cpu_out=np.load(p1+'output'+str(j)+'_'+str(i)+'.npy')
            gpu_out=np.load(p2+'output'+str(j)+'_'+str(i)+'.npy')
            #求均方差
            sum1+=cpu_out
            sum2+=gpu_out
            list_cpu.append(cpu_out)
            list_gpu.append(gpu_out)


        avg1=sum1/1000
        avg2=sum2/1000
        diff=np.mean(np.abs(avg1-avg2))
        print("diff between tf's cpu and gpu:",diff)
        sd_cpu=np.zeros((1,8,6,6))
        sd_gpu=np.zeros((1,8,6,6))

        for i in range(1000):
            cpu_out = list_cpu[i]
            gpu_out = list_gpu[i]
            sd_cpu+=np.square(cpu_out-avg1)
            sd_gpu+=np.square(gpu_out-avg2)

        sd_cpu=np.sqrt(sd_cpu/1000)
        sd_gpu=np.sqrt(sd_gpu/1000)
        print("第"+str(j)+"个输入的"+"标准差-cpu为：",sd_cpu)
        print("第"+str(j)+"个输入的"+"标准差-gpu为：",sd_gpu)
        d.append(j)
        d.append(sd_cpu)
        d.append(sd_gpu)
        csv_writer.writerow(d)

    out.close()

def conv_for4(p1,p2):
    for j in range(20):

        sum1=np.zeros((2,2))
        sum2=np.zeros((2,2))
        list_cpu=[]
        list_gpu=[]

        for i in range(1000):
            cpu_out=np.load(p1+'output'+str(j)+'_'+str(i)+'.npy')
            gpu_out=np.load(p2+'output'+str(j)+'_'+str(i)+'.npy')
            #求均方差
            sum1+=cpu_out
            sum2+=gpu_out
            list_cpu.append(cpu_out)
            list_gpu.append(gpu_out)


        avg1=sum1/1000
        avg2=sum2/1000
        diff=np.mean(np.abs(avg1-avg2))
        print("diff between tf's cpu and gpu:",diff)
        sd_cpu=np.zeros((2,2))
        sd_gpu=np.zeros((2,2))

        for i in range(1000):
            # cpu_out = np.load(p1 + 'output' + str(i) + '.npy')
            # gpu_out = np.load(p2 + 'output' + str(i) + '.npy')
            cpu_out=list_cpu[i]
            gpu_out=list_gpu[i]
            sd_cpu+=np.square(cpu_out-avg1)
            sd_gpu+=np.square(gpu_out-avg2)

        sd_cpu=np.sqrt(sd_cpu/1000)
        sd_gpu=np.sqrt(sd_gpu/1000)
        print("第"+str(j)+"个输入的"+"标准差-cpu为：",sd_cpu)
        print("第"+str(j)+"个输入的"+"标准差-gpu为：",sd_gpu)


def conv_forNorm(p1,p2):
    for j in range(20):

        sum1=np.zeros((1,2,4,4))
        sum2=np.zeros((1,2,4,4))
        list_cpu=[]
        list_gpu=[]


        for i in range(1000):
            cpu_out=np.load(p1+'output'+str(j)+'_'+str(i)+'.npy')
            gpu_out=np.load(p2+'output'+str(j)+'_'+str(i)+'.npy')
            #求均方差
            sum1+=cpu_out
            sum2+=gpu_out
            list_cpu.append(cpu_out)
            list_gpu.append(gpu_out)


        avg1=sum1/1000
        avg2=sum2/1000
        diff=np.mean(np.abs(avg1-avg2))
        print("diff between tf's cpu and gpu:",diff)
        sd_cpu=np.zeros((1,2,4,4))
        sd_gpu=np.zeros((1,2,4,4))

        for i in range(1000):
            # cpu_out = np.load(p1 + 'output' + str(i) + '.npy')
            # gpu_out = np.load(p2 + 'output' + str(i) + '.npy')
            cpu_out=list_cpu[i]
            gpu_out=list_gpu[i]
            sd_cpu+=np.square(cpu_out-avg1)
            sd_gpu+=np.square(gpu_out-avg2)

        sd_cpu=np.sqrt(sd_cpu/1000)
        sd_gpu=np.sqrt(sd_gpu/1000)
        print("第"+str(j)+"个输入的"+"标准差-cpu为：",sd_cpu)
        print("第"+str(j)+"个输入的"+"标准差-gpu为：",sd_gpu)

def conv_forNorm_tf(p1,p2):
    out = open(file="/home/finley/OperatorTest/question3/1.csv", mode="a", newline='')
    csv_writer = csv.writer(out)
    csv_writer.writerow(["No.", "diff"])
    for j in range(20):
        d=[]
        d.append(j)

        sum1=np.zeros((1,4,4,2))
        sum2=np.zeros((1,4,4,2))
        list_cpu=[]
        list_gpu=[]


        for i in range(1000):
            cpu_out=np.load(p1+'output'+str(j)+'_'+str(i)+'.npy')
            gpu_out=np.load(p2+'output'+str(j)+'_'+str(i)+'.npy')
            #求均方差
            sum1+=cpu_out
            sum2+=gpu_out
            list_cpu.append(cpu_out)
            list_gpu.append(gpu_out)


        avg1=sum1/1000
        avg2=sum2/1000
        diff=np.mean(np.abs(avg1-avg2))
        print("diff between tf's cpu and gpu:",diff)
        d.append(diff)
        sd_cpu=np.zeros((1,4,4,2))
        sd_gpu=np.zeros((1,4,4,2))

        for i in range(1000):
            # cpu_out = np.load(p1 + 'output' + str(i) + '.npy')
            # gpu_out = np.load(p2 + 'output' + str(i) + '.npy')
            cpu_out=list_cpu[i]
            gpu_out=list_gpu[i]
            sd_cpu+=np.square(cpu_out-avg1)
            sd_gpu+=np.square(gpu_out-avg2)

        sd_cpu=np.sqrt(sd_cpu/1000)
        sd_gpu=np.sqrt(sd_gpu/1000)
        print("第"+str(j)+"个输入的"+"标准差-cpu为：",sd_cpu)
        print("第"+str(j)+"个输入的"+"标准差-gpu为：",sd_gpu)
        csv_writer.writerow(d)
    out.close()


def conv_forPooling(p1,p2):
    for j in range(20):

        sum1=np.zeros((1,2,3,3))
        sum2=np.zeros((1,2,3,3))
        list_cpu=[]
        list_gpu=[]


        for i in range(1000):
            cpu_out=np.load(p1+'output'+str(j)+'_'+str(i)+'.npy')
            gpu_out=np.load(p2+'output'+str(j)+'_'+str(i)+'.npy')
            #求均方差
            sum1+=cpu_out
            sum2+=gpu_out
            list_cpu.append(cpu_out)
            list_gpu.append(gpu_out)


        avg1=sum1/1000
        avg2=sum2/1000
        diff=np.mean(np.abs(avg1-avg2))
        print("diff between tf's cpu and gpu:",diff)
        sd_cpu=np.zeros((1,2,3,3))
        sd_gpu=np.zeros((1,2,3,3))

        for i in range(1000):
            # cpu_out = np.load(p1 + 'output' + str(i) + '.npy')
            # gpu_out = np.load(p2 + 'output' + str(i) + '.npy')
            cpu_out=list_cpu[i]
            gpu_out=list_gpu[i]
            sd_cpu+=np.square(cpu_out-avg1)
            sd_gpu+=np.square(gpu_out-avg2)

        sd_cpu=np.sqrt(sd_cpu/1000)
        sd_gpu=np.sqrt(sd_gpu/1000)
        print("第"+str(j)+"个输入的"+"标准差-cpu为：",sd_cpu)
        print("第"+str(j)+"个输入的"+"标准差-gpu为：",sd_gpu)

def conv_forPooling_tf(p1,p2):
    for j in range(20):

        sum1=np.zeros((1,3,3,2))
        sum2=np.zeros((1,3,3,2))
        list_cpu=[]
        list_gpu=[]


        for i in range(1000):
            cpu_out=np.load(p1+'output'+str(j)+'_'+str(i)+'.npy')
            gpu_out=np.load(p2+'output'+str(j)+'_'+str(i)+'.npy')
            #求均方差
            sum1+=cpu_out
            sum2+=gpu_out
            list_cpu.append(cpu_out)
            list_gpu.append(gpu_out)


        avg1=sum1/1000
        avg2=sum2/1000
        diff=np.mean(np.abs(avg1-avg2))
        print("diff between tf's cpu and gpu:",diff)
        sd_cpu=np.zeros((1,3,3,2))
        sd_gpu=np.zeros((1,3,3,2))

        for i in range(1000):
            # cpu_out = np.load(p1 + 'output' + str(i) + '.npy')
            # gpu_out = np.load(p2 + 'output' + str(i) + '.npy')
            cpu_out=list_cpu[i]
            gpu_out=list_gpu[i]
            sd_cpu+=np.square(cpu_out-avg1)
            sd_gpu+=np.square(gpu_out-avg2)

        sd_cpu=np.sqrt(sd_cpu/1000)
        sd_gpu=np.sqrt(sd_gpu/1000)
        print("第"+str(j)+"个输入的"+"标准差-cpu为：",sd_cpu)
        print("第"+str(j)+"个输入的"+"标准差-gpu为：",sd_gpu)

def difffor4_MNN(p1):
    for j in range(20):
        sum1=np.zeros((2,2))
        list_cpu=[]

        for i in range(1000):
            cpu_out=np.load(p1+'output'+str(j)+'_'+str(i)+'.npy')
            #求均方差
            sum1+=cpu_out

            list_cpu.append(cpu_out)

        avg1=sum1/1000

        sd_cpu=np.zeros((2,2))

        for i in range(1000):
            cpu_out=list_cpu[i]

            sd_cpu+=np.square(cpu_out-avg1)


        sd_cpu=np.sqrt(sd_cpu/1000)

        print("第"+str(j)+"个输入的"+"标准差-cpu为：",sd_cpu)

def diff_MNN_forPooling(p1):
    for j in range(20):
        sum1=np.zeros((1,2,3,3))
        list_cpu=[]

        for i in range(1000):
            cpu_out=np.load(p1+'output'+str(j)+'_'+str(i)+'.npy')
            #求均方差
            sum1+=cpu_out
            list_cpu.append(cpu_out)


        avg1=sum1/1000
        sd_cpu=np.zeros((1,2,3,3))


        for i in range(1000):
            # cpu_out = np.load(p1 + 'output' + str(i) + '.npy')
            # gpu_out = np.load(p2 + 'output' + str(i) + '.npy')
            cpu_out=list_cpu[i]
            sd_cpu+=np.square(cpu_out-avg1)

        sd_cpu=np.sqrt(sd_cpu/1000)

        print("第"+str(j)+"个输入的"+"标准差-cpu为：",sd_cpu)

def diff_MNN_forNorm(p1):
    for j in range(20):

        sum1=np.zeros((1,2,4,4))

        list_cpu=[]



        for i in range(1000):
            cpu_out=np.load(p1+'output'+str(j)+'_'+str(i)+'.npy')

            #求均方差
            sum1+=cpu_out

            list_cpu.append(cpu_out)



        avg1=sum1/1000

        sd_cpu=np.zeros((1,2,4,4))


        for i in range(1000):
            # cpu_out = np.load(p1 + 'output' + str(i) + '.npy')
            # gpu_out = np.load(p2 + 'output' + str(i) + '.npy')
            cpu_out=list_cpu[i]

            sd_cpu+=np.square(cpu_out-avg1)


        sd_cpu=np.sqrt(sd_cpu/1000)

        print("第"+str(j)+"个输入的"+"标准差-cpu为：",sd_cpu)


def conv_mnn(p1):
    for j in range(20):
        sum1=np.zeros((1,8,6,6))

        list_cpu=[]

        for i in range(1000):
            cpu_out=np.load(p1+'output'+str(j)+'_'+str(i)+'.npy')

            #求均方差
            sum1+=cpu_out

            list_cpu.append(cpu_out)



        avg1=sum1/1000

        sd_cpu=np.zeros((1,8,6,6))


        for i in range(1000):
            cpu_out = list_cpu[i]

            sd_cpu+=np.square(cpu_out-avg1)


        sd_cpu=np.sqrt(sd_cpu/1000)

        print("第"+str(j)+"个输入的"+"标准差-cpu为：",sd_cpu)


if __name__=='__main__':
    # print("conv---------------------------------------------------")
    # conv('/home/finley/OperatorTest/question3/conv_tf_cpu_output/','/home/finley/OperatorTest/question3/conv_tf_gpu_output/')
    # conv_torch('/home/finley/OperatorTest/question3/conv_torch_cpu_output/','/home/finley/OperatorTest/question3/conv_torch_gpu_output/')

    #
    # print("tanh--------------------------------------------------")
    # conv_for4('/home/finley/OperatorTest/question3/tanh_tf_cpu_output/','/home/finley/OperatorTest/question3/tanh_tf_gpu_output/')
    # conv_for4('/home/finley/OperatorTest/question3/tanh_torch_cpu_output/','/home/finley/OperatorTest/question3/tanh_torch_gpu_output/')

    # print("relu--------------------------------------------------")
    #
    # conv_for4('/home/finley/OperatorTest/question3/relu_tf_cpu_output/','/home/finley/OperatorTest/question3/relu_tf_gpu_output/')
    # conv_for4('/home/finley/OperatorTest/question3/relu_torch_cpu_output/','/home/finley/OperatorTest/question3/relu_torch_gpu_output/')
    # print("softmax--------------------------------------------------")
    #
    # conv_for4('/home/finley/OperatorTest/question3/softmax_tf_cpu_output/','/home/finley/OperatorTest/question3/softmax_tf_gpu_output/')
    # conv_for4('/home/finley/OperatorTest/question3/softmax_torch_cpu_output/','/home/finley/OperatorTest/question3/softmax_torch_gpu_output/')
    # print("sigmoid--------------------------------------------------")
    #
    # # conv_for4('/home/finley/OperatorTest/question3/sigmoid_tf_cpu_output/','/home/finley/OperatorTest/question3/sigmoid_tf_gpu_output/')
    # # conv_for4('/home/finley/OperatorTest/question3/sigmoid_torch_cpu_output/','/home/finley/OperatorTest/question3/sigmoid_torch_gpu_output/')
    # print("norm--------------------------------------------------")
    #
    # conv_forNorm('/home/finley/OperatorTest/question3/norm_torch_cpu_output/','/home/finley/OperatorTest/question3/norm_torch_gpu_output/')
    # conv_forNorm_tf('/home/finley/OperatorTest/question3/norm_tf_cpu_output/','/home/finley/OperatorTest/question3/norm_tf_gpu_output/')
    print("pooling--------------------------------------------------")

    conv_forPooling('/home/finley/OperatorTest/question3/pooling_torch_cpu_output/','/home/finley/OperatorTest/question3/pooling_torch_gpu_output/')
    conv_forPooling_tf('/home/finley/OperatorTest/question3/pooling_tf_cpu_output/','/home/finley/OperatorTest/question3/pooling_tf_gpu_output/')

    # difffor4_MNN('/home/finley/OperatorTest/question3/sigmoid_mnn_cpu_output/')
    # difffor4_MNN('/home/finley/OperatorTest/question3/softmax_mnn_cpu_output/')
    # difffor4_MNN('/home/finley/OperatorTest/question3/relu_mnn_cpu_output/')
    # difffor4_MNN('/home/finley/OperatorTest/question3/tanh_mnn_cpu_output/')
    # diff_MNN_forNorm('/home/finley/OperatorTest/question3/norm_mnn_cpu_output/')
    # conv_mnn('/home/finley/OperatorTest/question3/conv_mnn_cpu_output/')


    # x = np.random.randn(1, 2, 4, 4)
    # x_torch = torch.Tensor(x)
    # x_tf = tf.convert_to_tensor(x.transpose((0, 2, 3, 1)), dtype=tf.float32)
    # tf_pooling = tf.nn.max_pool(x_tf, [1, 2, 2, 1], [1, 1, 1, 1], padding='VALID')
    # sess = tf.Session()
    # tf_result = sess.run(tf_pooling)               #1,3,3,2
    # print(tf_result.shape)
    #
    # torch_pooling = torch.nn.MaxPool2d(kernel_size=2, stride=1)
    # torch_res = torch_pooling(x_torch)
    # print(torch_res.shape)           #1,2,3,3
    #
    # sess = tf.Session()
    # a_mean, a_var = tf.nn.moments(x_tf, axes=[1, 2], keep_dims=True)
    #
    #
    # tf_norm = tf.nn.batch_normalization(x_tf, a_mean, a_var, offset=None, scale=1, variance_epsilon=1e-05)
    # tf_result = sess.run(tf_norm)
    # print(tf_result.shape)                #1,4,4,2