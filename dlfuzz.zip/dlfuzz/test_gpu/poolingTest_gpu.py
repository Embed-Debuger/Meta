from __future__ import print_function
import os

os.environ['GLOG_minloglevel'] = '2'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

import numpy as np
import tensorflow as tf
import torch
import torch.nn.functional as F
import MNN
from tensorflow.python.framework import graph_util
import csv
import time
F_mnn = MNN.expr
tf.compat.v1.disable_eager_execution()

class Pytor_poolingNet(torch.nn.Module):
    def __init__(self):
        super(Pytor_poolingNet, self).__init__()
        self.torch_pooling=torch.nn.MaxPool2d(kernel_size=2,stride=1)

    def forward(self, inputs):
        x = self.torch_pooling(inputs)
        return x

def save_model(net,x):
    input_names = ['input']
    output_names = ['output']
    torch_to_onnx=torch.onnx.export(net, x, "pytorch_pooling.onnx", export_params=True, verbose=True,input_names=input_names, output_names=output_names)

def saveTopb(path):
    with tf.Session(graph=tf.Graph()) as sess:
        x = tf.placeholder(dtype=tf.float32, shape=(1,4,4,2), name="x")
        y=tf.nn.max_pool(x, [1, 2, 2, 1], [1, 1, 1, 1], padding='VALID',name='pooling')
        sess.run(tf.global_variables_initializer())
        constant_graph = graph_util.convert_variables_to_constants(sess, sess.graph_def,["x","pooling"])
        with tf.gfile.FastGFile(path, mode='wb') as f:
            f.write(constant_graph.SerializeToString())

class Net(MNN.nn.Module):
    def __init__(self):
        super(Net, self).__init__()

    def forward(self, x):
        x = F_mnn.max_pool(x, [2,2], [1,1],padding_mode=F_mnn.Padding_Mode.VALID)
        return x


def runMNNModel(path,x):
    interpreter = MNN.Interpreter(path)
    session = interpreter.createSession()
    input_tensor = interpreter.getSessionInput(session)
    tmp_input = MNN.Tensor((1, 2, 4, 4), MNN.Halide_Type_Float, \
                           x, MNN.Tensor_DimensionType_Caffe)
    input_tensor.copyFrom(tmp_input)
    interpreter.runSession(session)
    output_tensor = interpreter.getSessionOutput(session)
    tmp_output = MNN.Tensor((1, 2,3,3), MNN.Halide_Type_Float, np.ones([1,2,3,3]).astype(np.float32),
                            MNN.Tensor_DimensionType_Caffe)
    output_tensor.copyToHostTensor(tmp_output)
    # print(tmp_output.getShape())
    output = np.array(tmp_output.getData())
    output = output.astype(np.float32)
    output=output.reshape(1,2,3,3)
    return output

def runtfToMNNModel(path,x):     #tf原模型输入shape（1,4,4,2）
    interpreter = MNN.Interpreter(path)
    session = interpreter.createSession()
    input_tensor = interpreter.getSessionInput(session)
    tmp_input = MNN.Tensor((1, 4, 4, 2), MNN.Halide_Type_Float, \
                           x, MNN.Tensor_DimensionType_Tensorflow)
    input_tensor.copyFrom(tmp_input)
    interpreter.runSession(session)
    output_tensor = interpreter.getSessionOutput(session)
    tmp_output = MNN.Tensor((1, 3,3,2), MNN.Halide_Type_Float, np.ones([1,3,3,2]).astype(np.float32),
                            MNN.Tensor_DimensionType_Tensorflow)
    output_tensor.copyToHostTensor(tmp_output)
    # print(tmp_output.getShape())
    output = np.array(tmp_output.getData())
    output = output.astype(np.float32)
    output=output.reshape(1,3,3,2)
    return output

def func():
    out = open(file="/home/finley/OperatorTest/pooling_gpu/pooling_diff_data.csv", mode="a", newline='')
    csv_writer = csv.writer(out)
    csv_writer.writerow(["No.", "tf_torch_diff", "tf_torch_rediff", "tf_time", "torch_time"])

    path = "/home/finley/OperatorTest/pooling_gpu/pooling_input/"
    i=4999
    while 1:
        i+=1
        x_out = open(file=path + "input_" + str(i) + ".csv", mode="a", newline='')
        csv_writer1 = csv.writer(x_out)
        csv_writer1.writerow(["No.", "input"])
        d=[]
        xlist=[]
        xlist.append(i)

        x = np.random.randn(1, 2, 4, 4)
        # x_mnn = x.astype(np.float32)
        # x_mnn = F_mnn.const(x_mnn.flatten().tolist(), [1, 2, 4, 4], F_mnn.data_format.NCHW)

        x_tf = tf.convert_to_tensor(x.transpose((0, 2, 3, 1)), dtype=tf.float32)
        x_torch = torch.Tensor(x)
        xlist.append(x)

        # TF Pooling
        tf_s=time.time()
        sess = tf.compat.v1.Session()
        tf_pooling = tf.nn.max_pool(x_tf, [1, 2, 2, 1], [1, 1, 1, 1], padding='VALID')
        tf_result = sess.run(tf_pooling)
        tf_e=time.time()
        tf_time=tf_e-tf_s

        # PyTorch pooling
        torch_s=time.time()
        torch_pooling = torch.nn.MaxPool2d(kernel_size=2,stride=1)
        torch_res=torch_pooling(x_torch)
        torch_e=time.time()
        torch_time=torch_e-torch_s

        # model = Net()
        # x = np.random.randn(1, 2, 4, 4)
        # predict = model.forward(x_mnn)
        # print(predict.shape)



        # MNN 的pooling算子不可用

        # tor_trans = runMNNModel("D:torToMNN_pooling.mnn", x)
        # tf_trans = runtfToMNNModel("D:tenToMNN_pooling.mnn", x.transpose((0, 2, 3, 1)))


        diff = np.mean(np.abs(tf_result.transpose((0, 3, 1, 2)) - torch_res.detach().numpy()),dtype=np.float64)
        re_diff=np.abs(np.mean(np.abs(tf_result.transpose((0, 3, 1, 2)) - torch_res.detach().numpy())/torch_res.detach().numpy()))
        # print("the diff between pytorch and tensorflow is:",diff)

        # diff3 = np.mean(np.abs(torch_res.detach().numpy() - tor_trans))
        # re_diff3=np.abs(np.mean(np.abs(torch_res.detach().numpy() - tor_trans)/tor_trans))
        # print("the diff between pytorch and pytor_transToMNN is:", diff3)
        #
        # diff4 = np.mean(np.abs(tf_result - tf_trans))
        # re_diff4=np.abs(np.mean(np.abs(tf_result - tf_trans)/tf_trans))
        # print("the diff between tensorflow and tf_transToMNN is:", diff4)

        d.append(i)
        d.append(diff)
        d.append(re_diff)
        d.append(tf_time)
        d.append(torch_time)
        csv_writer.writerow(d)
        csv_writer1.writerow(xlist)
        x_out.close()
    #
    out.close()

    print("done")

if __name__=='__main__':
    # 创建pytorch、tf模型
    # net=Pytor_poolingNet()
    # x = np.random.randn(1, 2, 4, 4)
    # x_torch = torch.Tensor(x)
    # save_model(net,x_torch)
    #
    # saveTopb("tf_pooling.pb")

     func()



