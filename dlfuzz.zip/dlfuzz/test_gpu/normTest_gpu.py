import os
import csv
# os.environ['GLOG_minloglevel'] = '2'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
import tensorflow as tf
import torch
import torch.nn.functional as F
import MNN
from tensorflow.python.framework import graph_util
import time
F_mnn = MNN.expr
tf.compat.v1.disable_eager_execution()



def runMNNModel(path,x):
    interpreter = MNN.Interpreter(path)
    session = interpreter.createSession()
    input_tensor = interpreter.getSessionInput(session)

    tmp_input = MNN.Tensor((1, 2, 4, 4), MNN.Halide_Type_Float, \
                           x, MNN.Tensor_DimensionType_Caffe)
    input_tensor.copyFrom(tmp_input)
    interpreter.runSession(session)
    output_tensor = interpreter.getSessionOutput(session)
    tmp_output = MNN.Tensor((1, 2,4,4), MNN.Halide_Type_Float, np.ones([1,2,4,4]).astype(np.float32),
                            MNN.Tensor_DimensionType_Caffe)
    output_tensor.copyToHostTensor(tmp_output)
    # print(tmp_output.getShape())
    output = np.array(tmp_output.getData())
    output = output.astype(np.float32)
    output=output.reshape(1,2,4,4)
    return output

def runtfToMNNModel(path,x):     #tf原模型输入shape（1,4,4,2）
    interpreter = MNN.Interpreter(path)
    session = interpreter.createSession()
    input_tensor = interpreter.getSessionInput(session)
    tmp_input = MNN.Tensor((1, 4, 4, 2), MNN.Halide_Type_Float, \
                           x, MNN.Tensor_DimensionType_Tensorflow)
    input_tensor.copyFrom(tmp_input)
    interpreter.runSession(session)
    output_tensor = interpreter.getSessionOutput(session)
    tmp_output = MNN.Tensor((1, 4,4,2), MNN.Halide_Type_Float, np.ones([1,4,4,2]).astype(np.float32),
                            MNN.Tensor_DimensionType_Tensorflow)
    output_tensor.copyToHostTensor(tmp_output)
    # print(tmp_output.getShape())
    output = np.array(tmp_output.getData())
    output = output.astype(np.float32)
    output=output.reshape(1,4,4,2)
    return output

def func():
    out = open(file="/home/finley/OperatorTest/norm_gpu/norm_diff_data.csv", mode="a", newline='')
    csv_writer = csv.writer(out)
    csv_writer.writerow(["No.", "tf_torch_diff", "tf_torch_rediff", "tf_time", "torch_time"])

    path = "/home/finley/OperatorTest/norm_gpu/norm_input/"

    i=4999
    while 1:
        i+=1
        x_out = open(file=path+"input_"+str(i)+".csv", mode="a", newline='')
        csv_writer1 = csv.writer(x_out)
        csv_writer1.writerow(["No.", "input"])
        d=[]
        xlist=[]
        xlist.append(i)

        x = np.random.randn(1, 2, 4, 4)
        # x_mnn = x.astype(np.float32)
        # x_mnn = F_mnn.const(x_mnn.flatten().tolist(), [1, 2, 4, 4], F_mnn.data_format.NCHW)

        x_tf = tf.convert_to_tensor(x.transpose((0, 2, 3, 1)), dtype=tf.float32)
        x_torch = torch.Tensor(x)

        xlist.append(x)

        a_mean, a_var = tf.nn.moments(x_tf, axes=[1, 2])

        tf_t1=time.time()
        sess = tf.compat.v1.Session()
        tf_norm = tf.nn.batch_normalization(x_tf,a_mean,a_var,offset=None,scale=1,variance_epsilon=1e-05)
        tf_result = sess.run(tf_norm)
        tf_t2=time.time()
        tf_time=tf_t2-tf_t1

        # PyTorch batch_norm
        # torch_norm = F.batch_norm(x_torch,momentum = 0.99, eps = 1e-05)
        torch_t1=time.time()
        torch_norm=torch.nn.BatchNorm2d(2,momentum = 0.99)
        torch_res = torch_norm(x_torch)
        torch_t2=time.time()
        torch_time=torch_t2-torch_t1


        # MNN batch_norm
        # mnn_t1=time.time()
        # mnn_norm = MNN.nn.batch_norm(2)
        # mnn_res = mnn_norm(x_mnn)
        # mnn_t2=time.time()
        # mnn_time=mnn_t2-mnn_t1
        #
        #
        # mnn_res = np.array(mnn_res.read())
        # mnn_res=mnn_res.astype(np.float32)
        # mnn_res=mnn_res.reshape((1,2,4,4))


        # tor_trans=runMNNModel("D:torToMNN_norm.mnn",x)
        #
        # tf_trans=runtfToMNNModel("D:tenToMNN_norm.mnn",x.transpose((0, 2, 3, 1)))

        diff = np.mean(np.abs(tf_result.transpose((0, 3, 1, 2))- torch_res.detach().numpy()))
        re_diff=np.abs(np.mean(np.abs(tf_result.transpose((0, 3, 1, 2))- torch_res.detach().numpy())/torch_res.detach().numpy()))
        # print("the diff between pytorch and tensorflow is:", diff)

        # diff_tf_mnn=np.mean(np.abs(tf_result.transpose((0, 3, 1, 2))- mnn_res))
        # re_diff_tf_mnn=np.abs(np.mean(np.abs(tf_result.transpose((0, 3, 1, 2))- mnn_res)/mnn_res))
        # # print("the diff between tensorflow and mnn is:",diff_tf_mnn)
        #
        # diff2=np.mean(np.abs(torch_res.detach().numpy()- mnn_res))
        # re_diff2=np.abs(np.mean(np.abs(torch_res.detach().numpy()- mnn_res)/mnn_res))
        # # print("the diff between pytorch and mnn is:", diff2)
        #
        # diff3=np.mean(np.abs(torch_res.detach().numpy()- tor_trans))
        # re_diff3=np.abs(np.mean(np.abs(torch_res.detach().numpy()- tor_trans)/tor_trans))
        # # print("the diff between pytorch and pytor_transToMNN is:", diff3)
        #
        # diff4 = np.mean(np.abs(tf_result - tf_trans))
        # re_diff4=np.abs(np.mean(np.abs(tf_result- tf_trans)/tf_trans))
        # print("the diff between tensorflow and tf_transToMNN is:", diff4)

        d.append(i)
        d.append(diff)
        d.append(re_diff)
        d.append(tf_time)
        d.append(torch_time)
        csv_writer.writerow(d)
        csv_writer1.writerow(xlist)
        x_out.close()

    out.close()



if __name__=='__main__':
     func()
     #tf_norm_model("save/norm.ckpt")
    #ckptToPB("save/norm.ckpt","D:\\tf_norm.pb")
    # saveTopb("D:\\tfNorm.pb")  #succeed



