import tensorflow as tf
import numpy as np

tf.compat.v1.disable_eager_execution()

# x = np.random.randn(1, 3, 12, 12)
# # weights = torch.empty(3, 3, 3, 8)
# weights = torch.empty(2, 2, 3, 8)
# torch.nn.init.constant_(weights, 5e-2)

inputpath = "E:\input0.npy"
weightpath = "E:\weight0.npy"

x = np.load(inputpath)
weights = np.load(weightpath)
weights_tf = tf.convert_to_tensor(weights, dtype=tf.float32)
# x_tf = tf.convert_to_tensor(x.transpose((0, 2, 3, 1)), dtype=tf.float32)
x_tf = tf.convert_to_tensor(x, dtype=tf.float32)

weights_tf = tf.convert_to_tensor(weights, dtype=tf.float32)
# x_tf = tf.convert_to_tensor(x.transpose((0, 2, 3, 1)), dtype=tf.float32)  #(1,12,12,3)  ->(1,6,6,8)
x_tf = tf.convert_to_tensor(x, dtype=tf.float32)

stride=1
sess = tf.compat.v1.Session()
# sess = tf.Session()
tf_conv2d = tf.nn.conv2d(x_tf,
                         weights_tf,
                         strides=[1, stride, stride, 1],
                         padding="SAME",data_format="NCHW")
sess.run(tf.compat.v1.global_variables_initializer())
tf_result = sess.run(tf_conv2d)
print(tf_result.shape)



