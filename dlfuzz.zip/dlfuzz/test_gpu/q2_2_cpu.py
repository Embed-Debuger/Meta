import os
import csv
# os.environ['GLOG_minloglevel'] = '2'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
import tensorflow as tf
import torch
import torch.nn.functional as F
import MNN
from tensorflow.python.framework import graph_util
import time
F_mnn = MNN.expr

def func():
    inputpath = "/home/finley/OperatorTest/question3/inputfor2/"
    for j in range(20):
        x = np.load(inputpath + 'input' + str(j) + '.npy')
        path1 = '/home/finley/OperatorTest/question3/pooling_tf_cpu_output/'
        path2 = '/home/finley/OperatorTest/question3/pooling_torch_cpu_output/'

        path3 = '/home/finley/OperatorTest/question3/norm_tf_cpu_output/'
        path4 = '/home/finley/OperatorTest/question3/norm_torch_cpu_output/'

        out = open(file="/home/finley/OperatorTest/question3/pooling_cpu.csv", mode="a", newline='')
        csv_writer = csv.writer(out)
        csv_writer.writerow(["No.", "tf_cpu","torch_cpu","tf_time","torch_time"])

        out1 = open(file="/home/finley/OperatorTest/question3/norm_cpu.csv", mode="a", newline='')
        csv_writer1 = csv.writer(out1)
        csv_writer1.writerow(["No.", "tf_cpu", "torch_cpu", "tf_time", "torch_time"])

        for i in range(1000):
            print(i)
            d=[]
            d1=[]

            x_tf = tf.convert_to_tensor(x.transpose((0, 2, 3, 1)), dtype=tf.float32)
            x_torch = torch.Tensor(x)

            # TF Pooling
            tf_s = time.time()
            sess = tf.Session()
            tf_pooling = tf.nn.max_pool(x_tf, [1, 2, 2, 1], [1, 1, 1, 1], padding='VALID')
            tf_result = sess.run(tf_pooling)
            tf_e = time.time()
            tf_time = tf_e - tf_s
            np.save(path1 + 'output' + str(j)+'_'+ str(i) + '.npy', tf_result)

            # PyTorch pooling
            torch_s = time.time()
            torch_pooling = torch.nn.MaxPool2d(kernel_size=2, stride=1)
            torch_res = torch_pooling(x_torch)
            torch_e = time.time()
            torch_time = torch_e - torch_s
            np.save(path2 + 'output' + str(j)+'_'+ str(i) + '.npy', torch_res)

            d.append(i)
            d.append(tf_result)
            d.append(torch_res)
            d.append(tf_time)
            d.append(torch_time)
            csv_writer.writerow(d)

            a_mean, a_var = tf.nn.moments(x_tf, axes=[1, 2])

            tf_t1 = time.time()
            sess = tf.Session()
            tf_norm = tf.nn.batch_normalization(x_tf, a_mean, a_var, offset=None, scale=1, variance_epsilon=1e-05)
            tf_result = sess.run(tf_norm)
            tf_t2 = time.time()
            tf_time = tf_t2 - tf_t1
            np.save(path3 + 'output' +str(j)+'_'+ str(i) + '.npy', tf_result)

            # PyTorch batch_norm
            # torch_norm = F.batch_norm(x_torch,momentum = 0.99, eps = 1e-05)
            torch_t1 = time.time()
            torch_norm = torch.nn.BatchNorm2d(2, momentum=0.99)
            torch_res = torch_norm(x_torch)
            torch_t2 = time.time()
            torch_time = torch_t2 - torch_t1
            np.save(path4 + 'output' +str(j)+'_'+ str(i) + '.npy', torch_res.detach().numpy())

            d1.append(i)
            d1.append(tf_result)
            d1.append(torch_res)
            d1.append(tf_time)
            d1.append(torch_time)
            csv_writer1.writerow(d1)


        out.close()
        out1.close()


def forMNN():
    for j in range(20):
        x = np.random.randn(1, 2, 4, 4)
        path0 = '/home/finley/OperatorTest/question3/MNN_input_for2op/'
        path1 = '/home/finley/OperatorTest/question3/norm_mnn_cpu_output/'
        # path2 = '/home/finley/OperatorTest/question3/pooling_mnn_cpu_output/'


        out = open(file="/home/finley/OperatorTest/question3/norm_mnn.csv", mode="a", newline='')
        csv_writer = csv.writer(out)
        csv_writer.writerow(["No.", "mnn_cpu", "mnn_time"])

        # out1 = open(file="/home/finley/OperatorTest/question3/pooling_mnn.csv", mode="a", newline='')
        # csv_writer1 = csv.writer(out1)
        # csv_writer1.writerow(["No.", "mnn_cpu", "mnn_time"])


        np.save(path0 + 'input' + str(j) + '.npy', x)

        for i in range(1000):
            d = []
            # d1 = []
            x_mnn = x.astype(np.float32)
            x_mnn = F_mnn.const(x_mnn.flatten().tolist(), [1, 2, 4, 4], F_mnn.data_format.NCHW)

            # MNN norm
            mnn_t1 = time.time()
            mnn_norm = MNN.nn.batch_norm(2)
            mnn_res = mnn_norm(x_mnn)
            mnn_t2 = time.time()
            mnn_time = mnn_t2 - mnn_t1

            mnn_res = np.array(mnn_res.read())
            mnn_res = mnn_res.astype(np.float32)
            mnn_res = mnn_res.reshape((1, 2, 4, 4))

            np.save(path1 + 'output' + str(j) + '_' + str(i) + '.npy', mnn_res)
            d.append(i)
            d.append(mnn_res)
            d.append(mnn_time)
            csv_writer.writerow(d)


        out.close()




if __name__=='__main__':
    # func()
    func()

