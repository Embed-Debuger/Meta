import os


import numpy as np
import tensorflow as tf
import torch
import torch.nn.functional as F
os.environ['GLOG_minloglevel'] = '2'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

np.random.seed(0)
crashes = 0
#sess = tf.compat.v1.Session()
sess=tf.Session()
for i in range(5000):
    x = np.random.randn(1, 28, 28, 3)
    weights = np.full((11, 11, 3, 1), 1, np.float64)

    x_tf = tf.convert_to_tensor(x, dtype=tf.float64)
    x_torch = torch.from_numpy(x.transpose((0, 3, 1, 2)).astype(np.float64))
    # weights_torch = torch.from_numpy(np.full((11, 11, 3, 1), 1, np.float64).transpose((3, 2, 0, 1)))
    weights_tf = tf.convert_to_tensor(weights)
    weights_torch = torch.from_numpy(weights.transpose((3, 2, 0, 1)))

    # Tensorflow padding behavior. Assuming that kH == kW to keep this simple.
    stride = 4
    if x.shape[2] % stride == 0:
        pad = max(weights.shape[0] - stride, 0)
    else:
        pad = max(weights.shape[0] - (x.shape[2] % stride), 0)

    if pad % 2 == 0:
        pad_val = pad // 2
        padding = (pad_val, pad_val, pad_val, pad_val)
    else:
        pad_val_start = pad // 2
        pad_val_end = pad - pad_val_start
        padding = (pad_val_start, pad_val_end, pad_val_start, pad_val_end)

    x_torch = F.pad(x_torch, padding, "constant", 0)

    # TF Conv2D
    tf_conv2d = tf.nn.convolution(x_tf,
                                  weights_tf,
                                  strides=[stride, stride],
                                  padding="SAME")
    sess.run(tf.global_variables_initializer())
    tf_result = sess.run(tf_conv2d)
    # PyTorch Conv2D
    torch_conv2d = F.conv2d(x_torch, weights_torch, padding=0, stride=stride).numpy().transpose((0, 2, 3, 1))
    print(tf_result.shape)
    print(torch_conv2d.shape)
    diff = np.mean(np.abs(tf_result - torch_conv2d))
    print("%d crashes exist in %d cases, and the mean of abs Diff is %s." % (crashes, i + 1, format(diff)))
    # out = open(file="output.csv", mode="a");
    # if diff >= 3.2 * (10 ** -8):  # 华为精度误差允许范围10^-6
    #     crashes = crashes + 1
    #     out.writelines(
    #         "%d crashes exist in %d cases, and the mean of abs Diff is %s.\n" % (crashes, i + 1, format(diff)))
    #     print("%d crashes exist in %d cases, and the mean of abs Diff is %s." % (crashes, i + 1, format(diff)))
    # out.close()
