import numpy as np
import MNN

F_mnn = MNN.expr
def runMNNmodel(path,x):
    interpreter = MNN.Interpreter(path)
    session = interpreter.createSession()
    input_tensor = interpreter.getSessionInput(session)
    tmp_input = MNN.Tensor((1, 3, 12, 12), MNN.Halide_Type_Float, \
                           x, MNN.Tensor_DimensionType_Caffe)
    input_tensor.copyFrom(tmp_input)
    interpreter.runSession(session)
    output_tensor = interpreter.getSessionOutput(session)
    tmp_output = MNN.Tensor((1, 8, 6, 6), MNN.Halide_Type_Float, np.ones([1, 8, 6, 6]).astype(np.float32),
                            MNN.Tensor_DimensionType_Caffe)
    output_tensor.copyToHostTensor(tmp_output)
    # print(tmp_output.getShape())
    output = np.array(tmp_output.getData())
    output = output.astype(np.float32)
    return output

def transtoMNNdiff_pytor(fname,pytor_res):
    x = np.load(fname)
    x_mnn = x.astype(np.float32)
    x_mnn = F_mnn.const(x_mnn.flatten().tolist(), [1, 3, 12, 12], F_mnn.data_format.NCHW)
    output_mnn = runMNNmodel("D:torToMNN_conv.mnn", x)
    pytor_res = np.load(pytor_res)
    print("the diff between transtoMNN and pytorch is :", np.mean(np.abs(pytor_res - output_mnn)))

def transtoMNNdiff_tf(fname,tf_res):
    x = np.load(fname)
    x_mnn = x.astype(np.float32)
    x_mnn = F_mnn.const(x_mnn.flatten().tolist(), [1, 3, 12, 12], F_mnn.data_format.NCHW)
    output_mnn = runMNNmodel("D:tenToMNN_conv.mnn", x)
    output_mnn=output_mnn.reshape(1,8,6,6)
    tf_res = np.load(tf_res)
    print("the diff between transtoMNN and tf is :", np.mean(np.abs(tf_res - output_mnn)))

if __name__=='__main__':
    transtoMNNdiff_pytor("x.npy","py_res.npy")
    transtoMNNdiff_tf('tf_x.npy','tf_res.npy')
