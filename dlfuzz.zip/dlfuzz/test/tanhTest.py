import os
import csv
os.environ['GLOG_minloglevel'] = '2'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
import tensorflow as tf
import torch
import torch.nn.functional as F
import MNN
import sigmoidTest as s
import time
from tensorflow.python.framework import graph_util

F_mnn = MNN.expr

class Pytor_tanhNet(torch.nn.Module):
    def __init__(self):
        super(Pytor_tanhNet, self).__init__()
        self.torch_tanh=torch.nn.Tanh()

    def forward(self, inputs):
        x = self.torch_tanh(inputs)
        return x

def save_model(net,x):
    input_names = ['input']
    output_names = ['output']
    torch_to_onnx=torch.onnx.export(net, x, "pytorch_tanh.onnx", export_params=True, verbose=True,input_names=input_names, output_names=output_names)

def saveTopb(path):
    with tf.Session(graph=tf.Graph()) as sess:
        x = tf.placeholder(dtype=tf.float32, shape=(2,2), name="x")
        y=tf.nn.tanh(x,name="tanh")
        sess.run(tf.global_variables_initializer())
        constant_graph = graph_util.convert_variables_to_constants(sess, sess.graph_def,["x","tanh"])
        with tf.gfile.FastGFile(path, mode='wb') as f:
            f.write(constant_graph.SerializeToString())

def func():
    out = open(file="E:diff_data1//tanh_diff_data.csv", mode="a", newline='')
    csv_writer = csv.writer(out)
    csv_writer.writerow(["No.","tf_torch","torch_mnn","tf_mnn","tf_time","torch_time","mnn_time"])

    path = "E:diff_data1//tanh_x//"
    for i in range(5000):
        print(i)
        x_out = open(file=path + "input_" + str(i) + ".csv", mode="a", newline='')
        csv_writer1 = csv.writer(x_out)
        csv_writer1.writerow(["No.", "input"])
        d=[]
        xlist=[]
        xlist.append(i)
        x = np.random.randn(2,2)
        x_mnn = x.astype(np.float32)
        x_mnn = F_mnn.const(x_mnn.flatten().tolist(), [2,2], F_mnn.data_format.NCHW)

        x_tf = tf.convert_to_tensor(x, dtype=tf.float32)
        x_torch = torch.Tensor(x)
        xlist.append(x)

        #tf tanh
        tf_t1=time.time()
        sess = tf.Session()
        tf_norm = tf.nn.tanh(x_tf)
        tf_result = sess.run(tf_norm)
        tf_t2=time.time()
        tf_time=tf_t2-tf_t1

        #pytorch tanh
        torch_t1=time.time()
        torch_norm = torch.nn.Tanh()
        torch_res = torch_norm(x_torch)
        torch_t2=time.time()
        torch_time=torch_t2-torch_t1

        # mnn tanh
        mnn_t1=time.time()
        mnn_res=F_mnn.tanh(x_mnn).read()
        mnn_t2=time.time()
        mnn_time=mnn_t2-mnn_t1

        mnn_res=np.asarray(mnn_res)
        mnn_res = mnn_res.astype(np.float32)
        mnn_res = mnn_res.reshape((2,2))

        # pytor_trans = s.runMNNModel("D:torToMNN_tanh.mnn", x)
        # tf_trans = s.runMNNModel("D:tenToMNN_tanh.mnn", x)

        diff = np.mean(np.abs(tf_result - torch_res.detach().numpy()))
        re_diff=np.abs(np.mean(np.abs(tf_result - torch_res.detach().numpy())/torch_res.detach().numpy()))
        # print("the diff of tanh between pytorch and tensorflow is:", diff)

        diff_tf_mnn = np.mean(np.abs(tf_result - mnn_res))
        re_diff_tf_mnn=np.abs(np.mean(np.abs(tf_result - mnn_res)/mnn_res))
        # print("the diff of tanh between tensorflow and mnn is:", diff_tf_mnn)

        diff2 = np.mean(np.abs(torch_res.detach().numpy() - mnn_res))
        re_diff2=np.abs(np.mean(np.abs(torch_res.detach().numpy() - mnn_res)/mnn_res))
        # print("the diff of tanh between pytorch and mnn is:", diff2)

        # diff3 = np.mean(np.abs(torch_res.detach().numpy() - pytor_trans))
        # re_diff3=np.abs(np.mean(np.abs(torch_res.detach().numpy() - pytor_trans)/pytor_trans))
        # print("the diff of relu between pytorch and pytor_transTomnn is:", diff3)
        #
        # diff4 = np.mean(np.abs(tf_result - tf_trans))
        # re_diff4=np.abs(np.mean(np.abs(tf_result - tf_trans)/tf_trans))
        # print("the diff of relu between tensorflow and tf_transTomnn is:", diff4)

        d.append(i)
        d.append(re_diff)
        d.append(re_diff2)
        d.append(re_diff_tf_mnn)
        d.append(tf_time)
        d.append(torch_time)
        d.append(mnn_time)
        # d.append(re_diff3)
        # d.append(re_diff4)
        csv_writer.writerow(d)
        csv_writer1.writerow(xlist)
        x_out.close()

    out.close()

def runfor24():
    out = open(file="/home/finley/OperatorTest/tanh_cpu/tanh_diff_data.csv", mode="a", newline='')
    csv_writer = csv.writer(out)
    csv_writer.writerow(["No.", "tf_torch", "torch_mnn", "tf_mnn", "tf_time", "torch_time", "mnn_time"])

    path = "/home/finley/OperatorTest/tanh_cpu/tanh_input/"

    i = -1
    while 1:
        i+=1
        d=[]
        x = np.random.randn(2,2)
        x_mnn = x.astype(np.float32)
        x_mnn = F_mnn.const(x_mnn.flatten().tolist(), [2,2], F_mnn.data_format.NCHW)

        x_tf = tf.convert_to_tensor(x, dtype=tf.float32)
        x_torch = torch.Tensor(x)
        np.save(path + 'input_' + str(i) + '.npy', x)

        #tf tanh
        tf_t1=time.time()
        sess = tf.Session()
        tf_norm = tf.nn.tanh(x_tf)
        tf_result = sess.run(tf_norm)
        tf_t2=time.time()
        tf_time=tf_t2-tf_t1

        #pytorch tanh
        torch_t1=time.time()
        torch_norm = torch.nn.Tanh()
        torch_res = torch_norm(x_torch)
        torch_t2=time.time()
        torch_time=torch_t2-torch_t1

        # mnn tanh
        mnn_t1=time.time()
        mnn_res=F_mnn.tanh(x_mnn).read()
        mnn_t2=time.time()
        mnn_time=mnn_t2-mnn_t1

        mnn_res=np.asarray(mnn_res)
        mnn_res = mnn_res.astype(np.float32)
        mnn_res = mnn_res.reshape((2,2))



        diff = np.mean(np.abs(tf_result - torch_res.detach().numpy()))
        re_diff=np.abs(np.mean(np.abs(tf_result - torch_res.detach().numpy())/torch_res.detach().numpy()))
        # print("the diff of tanh between pytorch and tensorflow is:", diff)

        diff_tf_mnn = np.mean(np.abs(tf_result - mnn_res))
        re_diff_tf_mnn=np.abs(np.mean(np.abs(tf_result - mnn_res)/mnn_res))
        # print("the diff of tanh between tensorflow and mnn is:", diff_tf_mnn)

        diff2 = np.mean(np.abs(torch_res.detach().numpy() - mnn_res))
        re_diff2=np.abs(np.mean(np.abs(torch_res.detach().numpy() - mnn_res)/mnn_res))
        # print("the diff of tanh between pytorch and mnn is:", diff2)



        d.append(i)
        d.append(re_diff)
        d.append(re_diff2)
        d.append(re_diff_tf_mnn)
        d.append(tf_time)
        d.append(torch_time)
        d.append(mnn_time)

        csv_writer.writerow(d)

    out.close()


def func_trans():
    out = open(file="/home/finley/OperatorTest/transToMNN/tanh_tranToMNN.csv", mode="a", newline='')
    csv_writer = csv.writer(out)
    csv_writer.writerow(
        ["No.", "torch_transToMNN", "re_torch_transToMNN", "tf_transToMNN", "re_tf_transToMNN", "torch_time",
         "torch_trans_time", "tf_time", "tf_trans_time"])

    path = '/home/finley/OperatorTest/transToMNN/tanh_input/'
    for i in range(5000):
        print(i)
        d=[]
        x = np.random.randn(2,2)
        x_mnn = x.astype(np.float32)
        x_mnn = F_mnn.const(x_mnn.flatten().tolist(), [2,2], F_mnn.data_format.NCHW)

        # xlist.append(x)
        x_tf = tf.convert_to_tensor(x, dtype=tf.float32)
        x_torch = torch.Tensor(x)
        np.save(path+"input_"+str(i)+".npy",x)

        tf_t1 = time.time()
        sess = tf.Session()
        tf_norm = tf.nn.tanh(x_tf)
        tf_result = sess.run(tf_norm)
        tf_t2 = time.time()
        tf_time = tf_t2 - tf_t1

        # pytorch tanh
        torch_t1 = time.time()
        torch_norm = torch.nn.Tanh()
        torch_res = torch_norm(x_torch)
        torch_t2 = time.time()
        torch_time = torch_t2 - torch_t1

        t1=time.time()
        tf_trans=s.runMNNModel("/home/finley/OperatorTest/transToMNN/tenToMNN_tanh.mnn",x)
        t_tf=time.time()-t1

        t1=time.time()
        pytor_trans=s.runMNNModel("/home/finley/OperatorTest/transToMNN/torToMNN_tanh.mnn",x)
        t_tor=time.time()-t1


        diff3 = np.mean(np.abs(torch_res.detach().numpy() - pytor_trans))
        re_diff3=np.abs(np.mean(np.abs(pytor_trans - torch_res.detach().numpy())/pytor_trans))
        # print("the diff of sigmoid between pytorch and pytor_transToMNN is:", diff3)

        diff4 = np.mean(np.abs(tf_result - tf_trans))
        re_diff4=np.abs(np.mean(np.abs(tf_result - tf_trans)/tf_trans))
        # print("the diff of sigmoid between tensorflow and tf_transToMNN is:", diff4)


        d.append(i)
        d.append(diff3)
        d.append(re_diff3)
        d.append(diff4)
        d.append(re_diff4)
        d.append(torch_time)
        d.append(t_tor)
        d.append(tf_time)
        d.append(t_tf)
        csv_writer.writerow(d)

    out.close()


if __name__=='__main__':
    # 创建pytorch模型
    # x = np.random.randn(2, 2)
    # x_torch=torch.Tensor(x)
    # net=Pytor_tanhNet()
    # save_model(net,x_torch)
    #
    # 创建tf模型
    # saveTopb("tf_tanh.pb")

    runfor24()
