import torch
import numpy as np


tensor = torch.tensor([0.1234, 0.1237])
torch.round(tensor, decimals=3)