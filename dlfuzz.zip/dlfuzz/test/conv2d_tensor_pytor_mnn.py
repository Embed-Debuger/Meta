import os

os.environ['GLOG_minloglevel'] = '2'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
import tensorflow as tf
import torch
import torch.nn.functional as F
import MNN
import csv
import time
from threading import Timer
F_mnn = MNN.expr
np.random.seed(0)
crashes = 0

def fun():
    out = open(file="E:diff_data1//conv_tf_torch_mnn.csv", mode="a", newline='')
    csv_writer = csv.writer(out)
    csv_writer.writerow(["No.","torch_tf","torch_mnn","tf_mnn","torch_time","tf_timae","mnn_time"])

    file="E:diff_data1//conv_x//"
    start=time.time()
    for i in range(10000):
        x_out = open(file=file+"input_"+str(i), mode="a", newline='')
        csv_writer1 = csv.writer(x_out)
        csv_writer1.writerow(["No.", "input"])
        r=[]
        xlist=[]
        xlist.append(i)
        sess=tf.Session()
        x = np.random.randn(1, 3, 12, 12)
        stride = 2
        x_mnn = x.astype(np.float32)
        x_mnn = F_mnn.const(x_mnn.flatten().tolist(), [1, 3, 12, 12], F_mnn.data_format.NCHW)
        xlist.append(x)

        # MNN Conv2D
        mnn_t1=time.time()
        conv1 = MNN.nn.conv(3, 8, [2,2], stride=[2,2], padding=[0,0])
        mnn_conv2d = conv1(x_mnn)
        mnn_t2=time.time()
        mnn_time=mnn_t2-mnn_t1
        # print(mnn_conv2d.shape)
        mnn_conv2d=mnn_conv2d.read()
        p = conv1.parameters

        weights_mnn = p[1].read()
        weights_mnn = np.array(weights_mnn)
        weights_mnn = weights_mnn.astype(np.float32)
        weights = weights_mnn.reshape((2, 2, 3,8))
        weights_tf = tf.convert_to_tensor(weights, dtype=tf.float32)
        weights_torch = torch.Tensor(weights.transpose((3, 2, 0, 1)))
        # Tensorflow padding behavior. Assuming that kH == kW to keep this simple.

        if x.shape[2] % stride == 0:
            pad = max(weights.shape[0] - stride, 0)
        else:
            pad = max(weights.shape[0] - (x.shape[2] % stride), 0)

        if pad % 2 == 0:
            pad_val = pad // 2
            padding = (pad_val, pad_val, pad_val, pad_val)
        else:
            pad_val_start = pad // 2
            pad_val_end = pad - pad_val_start
            padding = (pad_val_start, pad_val_end, pad_val_start, pad_val_end)

        x_tf = tf.convert_to_tensor(x.transpose((0, 2, 3, 1)), dtype=tf.float32)
        x_torch = torch.Tensor(x)
        x_torch = F.pad(x_torch, padding, "constant", 0)


        # TF Conv2D

        tf_t1=time.time()
        tf_conv2d = tf.nn.conv2d(x_tf,
                                 weights_tf,
                                 strides=[1, stride, stride, 1],
                                 padding="SAME")

        sess.run(tf.global_variables_initializer())
        tf_result = sess.run(tf_conv2d)
        tf_t2=time.time()
        print(tf_result.shape)
        tf_time=tf_t2-tf_t1

        # PyTorch Conv2D
        torch_t1=time.time()
        torch_conv2d = F.conv2d(x_torch, weights_torch, padding=0, stride=stride)
        torch_t2=time.time()
        torch_time=torch_t2-torch_t1

        dis=np.abs(tf_result.transpose((0, 3, 1, 2)) - torch_conv2d.detach().numpy())
        diff = np.mean(np.abs(tf_result.transpose((0, 3, 1, 2)) - torch_conv2d.detach().numpy()))
        relative_diff1=np.abs(np.mean(dis/torch_conv2d.detach().numpy()))
        print(relative_diff1)

        mnn_conv2d=np.array(mnn_conv2d)
        mnn_conv2d=mnn_conv2d.astype(np.float32)
        mnn_conv2d=mnn_conv2d.reshape((1,8,6,6))

        diff1=np.mean(np.abs(mnn_conv2d-torch_conv2d.detach().numpy()))
        relative_diff2=np.abs(np.mean(np.abs(mnn_conv2d-torch_conv2d.detach().numpy())/mnn_conv2d))

        print("the diff between pytorch and mnn is:",np.mean(np.abs(mnn_conv2d-torch_conv2d.detach().numpy())))
        # print(torch_conv2d)
        # tf_result=tf_result.transpose((0, 3, 1, 2))
        # print(tf_result)
        diff2=np.mean(np.abs(mnn_conv2d - tf_result.transpose((0, 3, 1, 2))))
        relative_diff3 = np.abs(np.mean(np.abs(mnn_conv2d - tf_result.transpose((0, 3, 1, 2))) / mnn_conv2d))
        print("the diff between tensorflow and mnn is:", np.mean(np.abs(mnn_conv2d - tf_result.transpose((0, 3, 1, 2)))))

        r.append(i)
        r.append(relative_diff1)
        r.append(relative_diff2)
        r.append(relative_diff3)
        r.append(torch_time)
        r.append(tf_time)
        r.append(mnn_time)
        csv_writer.writerow(r)
        csv_writer1.writerow(xlist)
        x_out.close()
    out.close()
    end=time.time()
    print(str(end-start))
    print("done")


def runfor24():
    out = open(file="/home/finley/OperatorTest/conv_cpu/conv_diff_data1.csv", mode="a", newline='')
    # /out = open(file="E:\conv_cpu.csv", mode="a", newline='')
    csv_writer = csv.writer(out)
    csv_writer.writerow(["No.","tf_torch","torch_mnn","tf_mnn","tf_time","torch_time","mnn_time"])

    # path = "/home/finley/OperatorTest/conv_cpu/conv_input/"
    i = -1
    while 1:
        i+=1
        r = []
        sess = tf.Session()
        x = np.random.randn(1, 3, 12, 12)
        stride = 2
        x_mnn = x.astype(np.float32)
        x_mnn = F_mnn.const(x_mnn.flatten().tolist(), [1, 3, 12, 12], F_mnn.data_format.NCHW)
        np.save(path + 'input_' + str(i) + '.npy', x)

        # MNN Conv2D
        mnn_t1 = time.time()
        conv1 = MNN.nn.conv(3, 8, [2, 2], stride=[2, 2], padding=[0, 0])
        mnn_conv2d = conv1(x_mnn)
        mnn_t2 = time.time()
        mnn_time = mnn_t2 - mnn_t1
        # print(mnn_conv2d.shape)
        mnn_conv2d = mnn_conv2d.read()
        p = conv1.parameters

        weights_mnn = p[1].read()
        weights_mnn = np.array(weights_mnn)
        weights_mnn = weights_mnn.astype(np.float32)
        weights = weights_mnn.reshape((2, 2, 3, 8))
        weights_tf = tf.convert_to_tensor(weights, dtype=tf.float32)
        weights_torch = torch.Tensor(weights.transpose((3, 2, 0, 1)))
        # Tensorflow padding behavior. Assuming that kH == kW to keep this simple.

        if x.shape[2] % stride == 0:
            pad = max(weights.shape[0] - stride, 0)
        else:
            pad = max(weights.shape[0] - (x.shape[2] % stride), 0)

        if pad % 2 == 0:
            pad_val = pad // 2
            padding = (pad_val, pad_val, pad_val, pad_val)
        else:
            pad_val_start = pad // 2
            pad_val_end = pad - pad_val_start
            padding = (pad_val_start, pad_val_end, pad_val_start, pad_val_end)

        x_tf = tf.convert_to_tensor(x.transpose((0, 2, 3, 1)), dtype=tf.float32)
        x_torch = torch.Tensor(x)
        x_torch = F.pad(x_torch, padding, "constant", 0)

        # TF Conv2D
        global graph
        graph = tf.get_default_graph()
        tf_t1 = time.time()
        with graph.as_default():
            tf_conv2d = tf.nn.conv2d(x_tf,
                                     weights_tf,
                                     strides=[1, stride, stride, 1],
                                     padding="SAME")

            sess.run(tf.global_variables_initializer())
            tf_result = sess.run(tf_conv2d)
        tf_t2 = time.time()
        tf_time = tf_t2 - tf_t1

        # PyTorch Conv2D
        torch_t1 = time.time()
        torch_conv2d = F.conv2d(x_torch, weights_torch, padding=0, stride=stride)
        torch_t2 = time.time()
        torch_time = torch_t2 - torch_t1

        dis = np.abs(tf_result.transpose((0, 3, 1, 2)) - torch_conv2d.detach().numpy())
        diff = np.mean(np.abs(tf_result.transpose((0, 3, 1, 2)) - torch_conv2d.detach().numpy()))
        relative_diff1 = np.abs(np.mean(dis / torch_conv2d.detach().numpy()))


        mnn_conv2d = np.array(mnn_conv2d)
        mnn_conv2d = mnn_conv2d.astype(np.float32)
        mnn_conv2d = mnn_conv2d.reshape((1, 8, 6, 6))

        diff1 = np.mean(np.abs(mnn_conv2d - torch_conv2d.detach().numpy()))
        relative_diff2 = np.abs(np.mean(np.abs(mnn_conv2d - torch_conv2d.detach().numpy()) / mnn_conv2d))

        diff2 = np.mean(np.abs(mnn_conv2d - tf_result.transpose((0, 3, 1, 2))))
        relative_diff3 = np.abs(np.mean(np.abs(mnn_conv2d - tf_result.transpose((0, 3, 1, 2))) / mnn_conv2d))

        r.append(i)
        r.append(relative_diff1)
        r.append(relative_diff2)
        r.append(relative_diff3)
        r.append(torch_time)         #此处将torch和tf time位置换错！
        r.append(tf_time)
        r.append(mnn_time)
        csv_writer.writerow(r)
    out.close()

def test():

    # out = open(file="/home/finley/OperatorTest/conv_cpu/conv_diff_data.csv", mode="a", newline='')
    out = open(file="E:\conv_cpu2.csv", mode="a", newline='')
    csv_writer = csv.writer(out)
    print('ok')
    csv_writer.writerow(["No.","tf_time"])
    print('ok')

    # path = "/home/finley/OperatorTest/conv_cpu/conv_input/"
    i = -1
    while 1:
        i += 1
        r = []
        weights = torch.empty(2, 2, 3, 8)
        torch.nn.init.constant_(weights, 5e-2)
        x = np.random.randn(1, 3, 12, 12)
        # xlist.append(x)

        weights_tf = tf.convert_to_tensor(weights.numpy(), dtype=tf.float32)
        x_tf = tf.convert_to_tensor(x.transpose((0, 2, 3, 1)), dtype=tf.float32)

        stride=2
        # TF Conv2D

        tf_t1 = time.time()

        sess = tf.Session()
        tf_conv2d = tf.nn.conv2d(x_tf,
                                 weights_tf,
                                 strides=[1, stride, stride, 1],
                                 padding="SAME")

        sess.run(tf.global_variables_initializer())
        tf_result = sess.run(tf_conv2d)
        tf_t2 = time.time()
        tf_time = tf_t2 - tf_t1
        sess.close()


        # PyTorch Conv2D
        # torch_t1 = time.time()
        # torch_conv2d = F.conv2d(x_torch, weights_torch, padding=0, stride=stride)
        # torch_t2 = time.time()
        # torch_time = torch_t2 - torch_t1
        # torch.cuda.empty_cache()
        #
        # dis = np.abs(tf_result.transpose((0, 3, 1, 2)) - torch_conv2d.detach().numpy())
        # diff = np.mean(np.abs(tf_result.transpose((0, 3, 1, 2)) - torch_conv2d.detach().numpy()))
        # relative_diff1 = np.abs(np.mean(dis / torch_conv2d.detach().numpy()))
        #
        # mnn_conv2d = np.array(mnn_conv2d)
        # mnn_conv2d = mnn_conv2d.astype(np.float32)
        # mnn_conv2d = mnn_conv2d.reshape((1, 8, 6, 6))
        #
        # diff1 = np.mean(np.abs(mnn_conv2d - torch_conv2d.detach().numpy()))
        # relative_diff2 = np.abs(np.mean(np.abs(mnn_conv2d - torch_conv2d.detach().numpy()) / mnn_conv2d))
        #
        # diff2 = np.mean(np.abs(mnn_conv2d - tf_result.transpose((0, 3, 1, 2))))
        # relative_diff3 = np.abs(np.mean(np.abs(mnn_conv2d - tf_result.transpose((0, 3, 1, 2))) / mnn_conv2d))

        r.append(i)
        # r.append(relative_diff1)
        # r.append(relative_diff2)
        # r.append(relative_diff3)
        # r.append(torch_time)
        r.append(tf_time)
        # r.append(mnn_time)
        csv_writer.writerow(r)
    out.close()

def cleancache():
    torch.cuda.empty_cache()
    t = Timer(1, cleancache)
    t.start()

if __name__=='__main__':
    test()

