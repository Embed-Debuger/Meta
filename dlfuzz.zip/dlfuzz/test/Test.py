import os

os.environ["OMP_NUM_THREADS"] = "1"
import torch
import torch.multiprocessing as mp
from setproctitle import setproctitle as ptitle
import torch
import torch.optim as optim
import gc
from torch import nn
import torch.nn.functional as F
from memory_profiler import profile


class Network(torch.nn.Module):
    def __init__(self, num_inputs, num_outputs):
        super(Network, self).__init__()
        self.conv1 = nn.Conv2d(num_inputs, 32, 5, stride=1, padding=2)
        self.maxp1 = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(32, 64, 3, stride=1, padding=1)
        self.maxp2 = nn.MaxPool2d(2, 2)
        self.linear = nn.Linear(64 * 20 * 20, num_outputs)
        self.train()

    def forward(self, inputs):
        x = F.relu(self.maxp1(self.conv1(inputs)))
        x = F.relu(self.maxp2(self.conv2(x)))
        x = x.view(x.size(0), -1)
        return self.linear(x)


def debug_memory():
    import resource
    print('maxrss = {}'.format(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss))


@profile
def func():
    model = Network(1, 6)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.0001)
    mse_loss = nn.MSELoss()
    x = torch.randn([1, 1, 80, 80])
    y_ref = torch.randn([1, 6])
    while True:
        y = model(x)
        loss = mse_loss(y, y_ref)
        model.zero_grad()
        loss.backward(retain_graph=False)
        optimizer.step()
        del y, loss
        # debug_memory()


if __name__ == '__main__':
    ptitle('MemoryLeakTest')
    func()