from __future__ import print_function
import time
import numpy as np
import MNN
import torch
import torch.multiprocessing as mp
#from setproctitle import setproctitle as ptitle
import torch
import torch.optim as optim
import gc
from torch import nn
import torch.nn.functional as F
import tensorflow as tf
from tensorflow.python.framework import graph_util

nn = MNN.nn
F_mnn = MNN.expr

class MNNNet(nn.Module):

    def __init__(self):
        super(MNNNet, self).__init__()
        self.conv1 = nn.conv(3, 8, [2,2],stride=[2,2],padding=[0,0])

    def forward(self, x):
        # x = F_mnn.relu(self.conv1(x))
        x = self.conv1(x)
        return x


class PytorNet(torch.nn.Module):
    def __init__(self, num_inputs):
        super(PytorNet, self).__init__()
        self.conv1 = torch.nn.Conv2d(num_inputs, 8,2,stride=2, padding=0)


    def forward(self, inputs):
        # x = F.relu((self.conv1(inputs)))
        x=self.conv1(inputs)
        return x

def tensorNet(pb_file_path):
    with tf.Session(graph=tf.Graph()) as sess:
       # x_tf = tf.convert_to_tensor(x.transpose(0, 2, 3, 1), dtype=tf.float32,name='x')
#        print(x_tf.shape)
        x= tf.placeholder(tf.float32, (1,12,12,3),name='x')
        conv_weight = tf.Variable(tf.truncated_normal([2, 2, 3, 8],
                                                      stddev=0.1, dtype=tf.float32),name='weight')
        bias = tf.Variable(tf.zeros([8], dtype=tf.float32),name='b')
        conv = tf.nn.conv2d(x, conv_weight, strides=[1,2, 2,1], padding='SAME',name='conv')

       #  conv1 = tf.layers.conv2d(inputs=x, use_bias=True, filters=3, kernel_size=[3, 3], strides=2, padding='SAME')
        # conv = tf.nn.bias_add(conv, bias)
        sess.run(tf.global_variables_initializer())
        # convres = sess.run(conv).transpose(0,3,1,2)
        constant_graph = graph_util.convert_variables_to_constants(sess, sess.graph_def,['x','weight','conv'])
        with tf.gfile.FastGFile(pb_file_path, mode='wb') as f:
            f.write(constant_graph.SerializeToString())
#        return convres


def savePytorModel(model,path):
    torch.save(model,path)

def tensor_conv(tf_x,weight):
    sess = tf.Session()
    x_tf = tf.convert_to_tensor(tf_x.transpose((0, 2, 3, 1)), dtype=tf.float32)
    conv_weight = weight
    conv = tf.nn.conv2d(x_tf, conv_weight, strides=[1, 2, 2, 1], padding='SAME', name='conv')
    sess.run(tf.global_variables_initializer())
    tf_result = sess.run(conv)
    return tf_result.transpose((0, 3, 1, 2))




def transtoMNNdiff_pytor(fname,pytor_res):
    x = np.load(fname)
    print(x)
    x_mnn = x.astype(np.float32)
    # x_mnn = F_mnn.const(x_mnn.flatten().tolist(), [1, 3, 12, 12], F_mnn.data_format.NCHW)
    output_mnn = runMNNmodel("torToMNN_conv.mnn", x_mnn)
    pytor_res=np.load(pytor_res)
    print(pytor_res)
    print(output_mnn)
    print("the diff between transtoMNN and pytorch is :", np.mean(np.abs(pytor_res - output_mnn)))


def save_model(net,x,path):
    input_names = ['input']
    output_names = ['output']
    torch_to_onnx=torch.onnx.export(net, x, path, export_params=True, verbose=True,input_names=input_names, output_names=output_names)

def runMNNmodel(path,x):
    interpreter = MNN.Interpreter(path)
    session = interpreter.createSession()
    input_tensor = interpreter.getSessionInput(session)
    input_tensor=x
    # tensorflow version:
    # tmp_input = MNN.Tensor((1, 12, 12, 3), MNN.Halide_Type_Float, \
    #                        x, MNN.Tensor_DimensionType_Tensorflow)
    # input_tensor.copyFrom(tmp_input)
    interpreter.runSession(session)
    output_tensor = interpreter.getSessionOutput(session)
    #output=output_tensor.getData() #return data array
    print(output_tensor.getShape())
    output =np.array(output_tensor.getData())
     #return array
    output=output.astype(np.float32)
    return output

def func():
    pytor_model = PytorNet(3)
    MNN_model=MNNNet()
    x = np.random.randn(1, 3, 12, 12)
    x_tf = tf.convert_to_tensor(x.transpose((0, 2, 3, 1)), dtype=tf.float32)
    # out_tensor=tensorNet(x,"D:\\tensor")     #convert to pb file
    x_torch = torch.from_numpy(x.astype(np.float32))

    x_mnn=x.astype(np.float32)
    x_mnn= F_mnn.const(x_mnn.flatten().tolist(), [1,3, 12, 12], F_mnn.data_format.NCHW)
    x_input=F_mnn.const(x.flatten().tolist(), [1,12, 12, 3], F_mnn.data_format.NCHW)

    save_model(pytor_model,x_torch,"pytorch_conv.onnx")
    savePytorModel(pytor_model,'pytor_conv.pt')

    # tensorNet("tf_conv.pb")

if __name__ == '__main__':
    func()




