import os

os.environ['GLOG_minloglevel'] = '2'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
import tensorflow as tf
import torch
import torch.nn.functional as F
import MNN
from tensorflow import keras
from tensorflow.keras import layers

F_mnn = MNN.expr

np.random.seed(0)
crashes = 0
for i in range(3):
    # sess = tf.Session()

    # Create random weights and input
    weights = torch.empty(3, 3, 3, 8)
    torch.nn.init.constant_(weights, 5e-2)
    x = np.random.randn(1, 3, 10, 10)

    weights_tf = tf.convert_to_tensor(weights.numpy(), dtype=tf.float32)
    weights_torch = torch.Tensor(weights.permute((3, 2, 0, 1)))

    weights_mnn=F_mnn.const(weights_torch.flatten().tolist(), [8,3,3,3], F_mnn.data_format.NCHW)

    # Tensorflow padding behavior. Assuming that kH == kW to keep this simple.
    stride = 2
    if x.shape[2] % stride == 0:
        pad = max(weights.shape[0] - stride, 0)
    else:
        pad = max(weights.shape[0] - (x.shape[2] % stride), 0)

    if pad % 2 == 0:
        pad_val = pad // 2
        padding = (pad_val, pad_val, pad_val, pad_val)
    else:
        pad_val_start = pad // 2
        pad_val_end = pad - pad_val_start
        padding = (pad_val_start, pad_val_end, pad_val_start, pad_val_end)

    x_tf = tf.convert_to_tensor(x.transpose((0, 2, 3, 1)), dtype=tf.float32)
    x_torch = torch.Tensor(x)
    x_torch = F.pad(x_torch, padding, "constant", 0)
    x_mnn = x.astype(np.float32)
    x_mnn = F_mnn.const(x_mnn.flatten().tolist(), [1, 3, 10, 10], F_mnn.data_format.NCHW)

    # TF Conv2D

    # tf_conv2d = tf.nn.conv2d(x_tf,
    #                          weights_tf,
    #                          strides=[1, stride, stride, 1],
    #                          padding="SAME",dtype='float16'
    #                          )
    #
    # sess.run(tf.global_variables_initializer(),)
    # tf_result = sess.run(tf_conv2d)

    conv_tf=layers.Conv2D(
        8, [3,3], strides=(2, 2), padding='valid',
        dtype='float16'
    )
    out_1=conv_tf(x_tf)
    print(out_1)

    # PyTorch Conv2D
    torch_conv2d = F.conv2d(x_torch, weights_torch, padding=0, stride=stride)
    # diff = np.mean(np.abs(out_1.transpose((0, 3, 1, 2)) - torch_conv2d.detach().numpy()))
    # print(diff)

    # MNN Conv2D
    bias=[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
    bias=np.zeros((8,))
    bias_mnn=F_mnn.const(bias, [8,],F_mnn.data_format.NCHW)
    mnn_conv2d=F_mnn.conv2d(x_mnn,weights_mnn,bias=bias_mnn,stride=[stride,stride],padding=[0,0])
    print(mnn_conv2d.read())



    # out = open(file="output.csv", mode="a");
    # if diff >= 3.2 * (10 ** -8):  # 华为精度误差允许范围10^-6
    #     crashes = crashes + 1
    #     out.writelines(
    #         "%d crashes exist in %d cases, and the mean of abs Diff is %s.\n" % (crashes, i + 1, format(diff)))
    #     print("%d crashes exist in %d cases, and the mean of abs Diff is %s." % (crashes, i + 1, format(diff)))
    # out.close()