import netron
import onnx
import tensorflow as tf
import numpy as np
import MNN
import torch
import torch.multiprocessing as mp
import torch.nn.functional as F
import csv
import time

from tensorflow.python.platform import gfile
F_mnn = MNN.expr

class PytorNet(torch.nn.Module):
    def __init__(self, num_inputs):
        super(PytorNet, self).__init__()
        self.conv1 = torch.nn.Conv2d(num_inputs, 8,2,stride=2, padding=0)


    def forward(self, inputs):
        # x = F.relu((self.conv1(inputs)))
        x=self.conv1(inputs)
        return x

def loadOnnxModel(path):
    model = onnx.load(path)
    return model

def runMNNmodel(path,x):
    interpreter = MNN.Interpreter(path)
    session = interpreter.createSession()
    input_tensor = interpreter.getSessionInput(session)
    tmp_input = MNN.Tensor((1, 3, 12, 12), MNN.Halide_Type_Float, \
                           x, MNN.Tensor_DimensionType_Caffe)
    input_tensor.copyFrom(tmp_input)
    interpreter.runSession(session)
    output_tensor = interpreter.getSessionOutput(session)
    tmp_output = MNN.Tensor((1, 8, 6, 6), MNN.Halide_Type_Float, np.ones([1, 8, 6, 6]).astype(np.float32),
                            MNN.Tensor_DimensionType_Caffe)
    output_tensor.copyToHostTensor(tmp_output)
    # print(tmp_output.getShape())
    output = np.array(tmp_output.getData())
    output = output.astype(np.float32)
    output=output.reshape(1,8,6,6)
    return output

def runTFMNNmodel(path,x):
    interpreter = MNN.Interpreter(path)
    session = interpreter.createSession()
    input_tensor = interpreter.getSessionInput(session)
    tmp_input = MNN.Tensor((1, 12, 12, 3), MNN.Halide_Type_Float, \
                           x, MNN.Tensor_DimensionType_Tensorflow)
    input_tensor.copyFrom(tmp_input)
    interpreter.runSession(session)
    output_tensor = interpreter.getSessionOutput(session)
    tmp_output = MNN.Tensor((1, 6, 6, 8), MNN.Halide_Type_Float, np.ones([1, 6, 6, 8]).astype(np.float32),
                            MNN.Tensor_DimensionType_Tensorflow)
    output_tensor.copyToHostTensor(tmp_output)
    # print(tmp_output.getShape())
    output = np.array(tmp_output.getData())
    output = output.astype(np.float32)
    output=output.reshape(1,6,6,8)
    return output

def runPB(path,x):
    sess = tf.Session()
    with gfile.FastGFile(path, 'rb') as f:
        graph_def = tf.GraphDef()
        graph_def.ParseFromString(f.read())
        sess.graph.as_default()
        tf.import_graph_def(graph_def, name='') # 导入计算图

    # 需要有一个初始化的过程
    sess.run(tf.global_variables_initializer())

    # 需要先复原变量
    sess.run('weight:0')
    input_x = sess.graph.get_tensor_by_name('x:0')

    op = sess.graph.get_tensor_by_name('conv:0')

    ret = sess.run(op,  feed_dict={input_x:x})
    return ret

if __name__=='__main__':
    out = open(file="/home/finley/OperatorTest/transToMNN/conv_tranToMNN.csv", mode="a", newline='')
    csv_writer = csv.writer(out)
    csv_writer.writerow(["No.","torch_transToMNN","re_torch_transToMNN","tf_transToMNN","re_tf_transToMNN","torch_time","torch_trans_time","tf_time","tf_trans_time"])

    path='/home/finley/OperatorTest/transToMNN/conv_input/'

    for i in range(5000):
        print(i)
        d=[]
        x = np.random.randn(1, 3, 12, 12)
        x1=x.transpose((0, 2, 3, 1))
        x_tf = tf.convert_to_tensor(x.transpose((0, 2, 3, 1)), dtype=tf.float32)
        x_torch = torch.from_numpy(x.astype(np.float32))
        np.save(path+'input'+str(i)+'.npy',x)

        t1=time.time()
        tor_trans=runMNNmodel("/home/finley/OperatorTest/transToMNN/torToMNN_conv.mnn",x)
        t_tor2=time.time()-t1
        # print("the conv diff between pytorch and pytor_transToMNN is",np.mean(np.abs(pytor_res.detach().numpy(),tor_trans)))

        pytor_model = torch.load('/home/finley/OperatorTest/transToMNN/pytor_conv.pt')
        pytor_model.eval()
        t1=time.time()
        res=pytor_model(x_torch)
        t_tor=time.time()-t1

        diff1=np.mean(np.abs(res.detach().numpy()-tor_trans))
        re_diff1=np.abs(np.mean(np.abs(res.detach().numpy()-tor_trans)/tor_trans))
        # print("the conv diff between pytorch and pytor_transToMNN is",diff1)

        t1=time.time()
        tf_trans=runTFMNNmodel('/home/finley/OperatorTest/transToMNN/tenToMNN_conv.mnn',x1)
        t_tf2=time.time()-t1

        t1=time.time()
        tf_res=runPB('/home/finley/OperatorTest/transToMNN/tf_conv.pb',x1)
        t_tf=time.time()-t1
        diff2 = np.mean(np.abs(tf_res-tf_trans))
        re_diff2=np.abs(np.mean(np.abs(tf_res-tf_trans)/tf_trans))
        # print("the conv diff between tensorflow and tf_transToMNN is", diff2)

        d.append(i)
        d.append(diff1)
        d.append(re_diff1)
        d.append(diff2)
        d.append(re_diff2)
        d.append(t_tor)
        d.append(t_tor2)
        d.append(t_tf)
        d.append(t_tf2)
        csv_writer.writerow(d)


    out.close()
    print('done')
