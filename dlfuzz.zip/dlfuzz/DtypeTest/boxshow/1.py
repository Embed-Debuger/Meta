import csv
import os
import numpy as np
s_dir="E:\Dtype_test\\hb.csv"
s_dir1="E:\Dtype_test\\hb3.csv"

d_dir="E:\Dtype_test\opTestData2.0"
guided_strategies = ['max_guided', 'mean_guided', 'random']
operator_names = ['relu', 'sigmoid', 'softmax', 'tanh', 'conv2d', 'pooling', 'norm']
tf_versions = ['tf_cpu_2.0.0', 'tf_cpu_2.3.1', 'tf_cpu_2.4.0', 'tf_gpu_2.0.0', 'tf_gpu_2.3.1', 'tf_gpu_2.4.0']
def hebing():
    out = open(file=s_dir1, mode="a", newline='')
    csv_writer = csv.writer(out)
    for strategy_name in guided_strategies:
        for version_name in tf_versions:
            op_list = os.listdir(os.path.join(d_dir, strategy_name, version_name))
            for op in op_list:
                if not 'count' in op :
                    csv_reader=csv.reader(open(file=os.path.join(d_dir, strategy_name, version_name,op)))
                    for j,line in enumerate(csv_reader):
                        if j!=0:
                            for index in range(1,7):
                                l=[]
                                l.append(line[index])
                                l.append(line[index+7])
                                l.append(op.split('.')[0])
                                l.append(version_name.split('_')[1].upper())
                                csv_writer.writerow(l)
    out.close()


def pro(f1,f2):
    out=open(file=f2,mode='a',newline='')
    csv_w=csv.writer(out)
    read=open(file=f1)
    csv_r=csv.reader(read)
    for line in csv_r:
        data=[]
        data.append(line[0])
        data.append(line[1])
        if len(line[2].split('_'))>=2:
            data.append(line[2].split('_')[1].lower())
        else:
            data.append(line[2].lower())
        data.append(line[3])

        csv_w.writerow(data)
    out.close()
    read.close()



def sp(f,f1):
    reader=csv.reader(open(file=f))
    w1=csv.writer(open(file=f1,mode='a',newline=''))
    # w2=csv.writer(open(file=f2,mode='a',newline=''))
    # w3=csv.writer(open(file=f3,mode='a',newline=''))
    # w4=csv.writer(open(file=f4,mode='a',newline=''))
    # w5=csv.writer(open(file=f5,mode='a',newline=''))
    # w6=csv.writer(open(file=f6,mode='a',newline=''))
    # w7=csv.writer(open(file=f7,mode='a',newline=''))
    for line in reader:
        if line[2]=='conv2d':
            w1.writerow(line)
        # elif line[2]=="norm":
        #     w2.writerow(line)
        # elif line[2]=="pooling":
        #     w3.writerow(line)
        # elif line[2]=="relu":
        #     w4.writerow(line)
        # elif line[2]=="sigmoid":
        #     w5.writerow(line)
        # elif line[2]=="softmax":
        #     w6.writerow(line)
        # elif line[2]=="tanh":
        #     w7.writerow(line)

def getmax(f,w,s):
    cr=csv.reader((open(file=f)))
    cw=csv.writer(open(file=w,mode='a',newline=''))
    m1=0
    m2=0
    index1=0
    index2=0
    p1=''
    p2=''
    res=[]
    res.append(s)
    # res.append(cr[0][2])
    for i,line in enumerate(cr):
        if float(line[0])>m1:
            m1=float(line[0])
            index1=i
            p1=line[3]
        if float(line[1])>m2:
            m2=float(line[1])
            index2=i
            p2=line[3]
    res.append(m1)
    res.append(index1)
    res.append(p1)
    res.append(m2)
    res.append(index2)
    res.append(p2)
    cw.writerow(res)











if __name__=='__main__':
    # hebing()
    # pro("E:\Dtype_test\\hb.csv","E:\Dtype_test\\hb2.csv")
    sp("E:\Dtype_test\\hb4.csv","E:\split_\\conv.csv")

    # hebing()
    # pro("E:\Dtype_test\\hb3.csv","E:\Dtype_test\\hb4.csv")
    getmax("E:\split_\\conv.csv","E:\\zuizhongjieguo.csv","conv2d")
    # getmax("E:\split_\\norm.csv","E:\\zuizhongjieguo.csv","norm")
    # getmax("E:\split_\\pooling.csv","E:\\zuizhongjieguo.csv","pooling")
    # getmax("E:\split_\\relu.csv","E:\\zuizhongjieguo.csv","relu")
    # getmax("E:\split_\\sigmoid.csv","E:\\zuizhongjieguo.csv","sigmoid")
    # getmax("E:\split_\\softmax.csv","E:\\zuizhongjieguo.csv","softmax")
    # getmax("E:\split_\\tanh.csv","E:\\zuizhongjieguo.csv","tanh")
