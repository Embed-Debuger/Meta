# Import Data
import os
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt

import seaborn as sns

# tips = pd.read_csv("E:\Dtype_test\\hb2.csv")
tips = pd.read_csv("runtime.csv")
# Draw Plot
# plt.figure(figsize=(13,10), dpi= 80)
# sns.boxplot(x='class', y='hwy', data=df, notch=False)

# Add N Obs inside boxplot (optional)
# def add_n_obs(df,group_col,y):
#     medians_dict = {grp[0]:grp[1][y].median() for grp in df.groupby(group_col)}
#     xticklabels = [x.get_text() for x in plt.gca().get_xticklabels()]
#     n_obs = df.groupby(group_col)[y].size().values
#     for (x, xticklabel), n_ob in zip(enumerate(xticklabels), n_obs):
#         # plt.text(x, medians_dict[xticklabel]*1.01, "#obs : "+str(n_ob), horizontalalignment='center', fontdict={'size':14}, color='white')
#         plt.text(x, medians_dict[xticklabel] * 1.01, "#obs : " + str(n_ob), horizontalalignment='center',
#                  fontdict={'size': 14}, color='white')
#
# add_n_obs(df,group_col='op_class',y='error1')
#
# # Decoration
# plt.title('error range for 7 ops', fontsize=22)
# plt.ylim(10, 40)
# plt.show()

# plt.savefig(os.path.join(save_dir, type + '.eps'), format='eps', dpi=1000)
# plt.savefig(os.path.join(save_dir, type + '.png'))

#

fig, axes = plt.subplots()
tips.boxplot(column=['crash_num'], by=['dl'], ax=axes,grid=False,showfliers = True,fontsize=9,showmeans=True)
#tips.boxplot(column=['runtime'], by=['dl'], ax=axes,grid=False,showfliers = True,fontsize=9,showmeans=True)
# column参数表示要绘制成箱形图的数据，可以是一列或多列
# by参数表示分组依据
axes.set_xlabel("")

plt.title('')
plt.show()
# axes.set_ylabel('values of tip_pct')
fig.savefig('p3.png')
# plt.savefig("E:\\box2.eps",format='eps', dpi=1000)
# # fig.savefig("E:\\box1.eps",format='eps', dpi=1200)


