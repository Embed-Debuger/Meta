import os

import numpy as np
import tensorflow as tf
import torch
import torch.nn.functional as F
import MNN
from tensorflow import keras
from tensorflow.keras import layers
import csv
import time
import math
np.random.seed(0)

def tf_random(f,g):
    out = open(file=f, mode="a", newline='')
    out1 = open(file=g, mode="a", newline='')

    csv_writer = csv.writer(out)
    csv_writer1 = csv.writer(out1)

    csv_writer.writerow(["No.", "16_64","32_64","time",
                         "isNaN"])
    csv_writer1.writerow(
        ["No.", "当前最大误差", "全局最大误差", "引起最大误差的输入编号"])
    h_error1 = 0

    for i in range(20):
        tmp1 = 0
        index1 = 0
        info = []
        info.append(i)
        for j in range(1000):
            print('j= ', j)
            x = np.random.randn(1, 3, 10, 10)
            res = []
            res.append(j)

            x_32 = input_withDiffDype(x, tf.float32)
            x_16 = input_withDiffDype(x, tf.float16)
            x_64 = input_withDiffDype(x, tf.float64)

            # TF Conv2D
            s = time.time()
            tf_conv_16 = tf_convWithDiffDype('float16')
            tf_conv_32 = tf_convWithDiffDype('float32')
            tf_conv_64 = tf_convWithDiffDype('float64')


            out_16_16_2 = tf_conv_16(x_16).numpy().astype(np.float64)
            out_32_32_2 = tf_conv_32(x_32).numpy().astype(np.float64)
            out_64_64 = tf_conv_64(x_64)

            diff1 = np.mean(np.abs(out_16_16_2-out_64_64))  # 低精度到高精度
            diff2 = np.mean(np.abs(out_32_32_2-out_64_64))  # 低精度到高精度

            e = time.time()

            res.append(diff1)
            res.append(diff2)
            res.append(e - s)


            for n in out_64_64.numpy().ravel():
                if math.isnan(n):
                    res.append("NAN")
                    break
            csv_writer.writerow(res)

            if max(res[1:3]) > tmp1:
                index1 = j
                tmp1 = max(res[1:3])

        h_error1 = max(h_error1, tmp1)
        info.append(tmp1)
        info.append(h_error1)
        info.append(index1)

        csv_writer1.writerow(info)

    out.close()
    out1.close()

if __name__=='__main__':
    tf_random("E:\Dtype_test\\random\\conv2d.csv","E:\Dtype_test\\random\\conv2d_count.csv")